--
-- PostgreSQL database dump
--

\restrict TuJxUmhKeLPlDmhXTutP6IUKXDd04zWxhT2wAraBShi33XmU4Vueaa08P6R6yPq

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AttachmentVariant; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AttachmentVariant" AS ENUM (
    'ORIGINAL',
    'THUMBNAIL'
);


--
-- Name: BillStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BillStatus" AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'APPROVED',
    'PAID'
);


--
-- Name: BoqStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BoqStatus" AS ENUM (
    'DRAFT',
    'FINALIZED'
);


--
-- Name: ExpenseCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExpenseCategory" AS ENUM (
    'MATERIAL',
    'LABOR',
    'TRANSPORT',
    'EQUIPMENT',
    'OFFICE',
    'OTHER'
);


--
-- Name: ExpenseStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExpenseStatus" AS ENUM (
    'UNPAID',
    'PARTIALLY_PAID',
    'PAID'
);


--
-- Name: HistoricalRateCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."HistoricalRateCategory" AS ENUM (
    'MATERIAL',
    'LABOR',
    'MACHINERY',
    'TRANSPORT'
);


--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'PARTIALLY_PAID',
    'PAID',
    'OVERDUE'
);


--
-- Name: LaborCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LaborCategory" AS ENUM (
    'SKILLED',
    'UNSKILLED',
    'SUPERVISORY'
);


--
-- Name: MilestoneStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MilestoneStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'DELAYED'
);


--
-- Name: OrganizationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrganizationType" AS ENUM (
    'GOVERNMENT',
    'PRIVATE'
);


--
-- Name: PaymentDirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentDirection" AS ENUM (
    'RECEIVED',
    'PAID'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CASH',
    'BANK_TRANSFER',
    'CHEQUE',
    'UPI',
    'CARD'
);


--
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'ACTIVE',
    'ON_HOLD',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: PurchaseOrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PurchaseOrderStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'PARTIALLY_RECEIVED',
    'RECEIVED',
    'CANCELLED'
);


--
-- Name: RfqStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RfqStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'CLOSED',
    'AWARDED',
    'CANCELLED'
);


--
-- Name: RfqVendorStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RfqVendorStatus" AS ENUM (
    'INVITED',
    'RESPONDED',
    'DECLINED'
);


--
-- Name: TenderAssigneeRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TenderAssigneeRole" AS ENUM (
    'OWNER',
    'ESTIMATOR',
    'REVIEWER',
    'OTHER'
);


--
-- Name: TenderPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TenderPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


--
-- Name: TenderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TenderStatus" AS ENUM (
    'DRAFT',
    'UPCOMING',
    'DOCUMENT_COLLECTION',
    'UNDER_STUDY',
    'BOQ_PREPARATION',
    'RATE_ANALYSIS',
    'APPROVAL_PENDING',
    'SUBMITTED',
    'TECHNICALLY_QUALIFIED',
    'FINANCIALLY_QUALIFIED',
    'WON',
    'LOST',
    'CANCELLED',
    'ARCHIVED'
);


--
-- Name: VendorCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VendorCategory" AS ENUM (
    'MATERIAL_SUPPLIER',
    'SERVICE_PROVIDER',
    'SUBCONTRACTOR',
    'EQUIPMENT_RENTAL'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id text NOT NULL,
    "originalName" text NOT NULL,
    "storedName" text NOT NULL,
    "mimeType" text NOT NULL,
    "sizeBytes" integer NOT NULL,
    hash text NOT NULL,
    "storageBucket" text NOT NULL,
    "storagePath" text NOT NULL,
    "entityType" text,
    "entityId" text,
    variant public."AttachmentVariant" DEFAULT 'ORIGINAL'::public."AttachmentVariant" NOT NULL,
    "parentId" text,
    version integer DEFAULT 1 NOT NULL,
    "uploadedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "documentGroupId" text,
    "documentType" text,
    "isCurrent" boolean DEFAULT true NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "actorId" text,
    action text NOT NULL,
    "entityType" text,
    "entityId" text,
    metadata jsonb,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_accounts (
    id text NOT NULL,
    name text NOT NULL,
    "accountNumber" text,
    "bankName" text,
    "ifscCode" text,
    "openingBalance" double precision DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: boq_item_rate_breakdowns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.boq_item_rate_breakdowns (
    id text NOT NULL,
    "boqItemId" text NOT NULL,
    "materialCost" double precision DEFAULT 0 NOT NULL,
    "laborCost" double precision DEFAULT 0 NOT NULL,
    "machineryCost" double precision DEFAULT 0 NOT NULL,
    "transportCost" double precision DEFAULT 0 NOT NULL,
    "overheadPercent" double precision DEFAULT 0 NOT NULL,
    "profitPercent" double precision DEFAULT 0 NOT NULL,
    "taxPercent" double precision DEFAULT 0 NOT NULL,
    "computedRate" double precision DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: boq_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.boq_items (
    id text NOT NULL,
    "boqId" text NOT NULL,
    "parentId" text,
    "itemCode" text,
    description text NOT NULL,
    category text,
    unit text,
    quantity double precision,
    rate double precision,
    amount double precision,
    remarks text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: boqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.boqs (
    id text NOT NULL,
    "tenderId" text NOT NULL,
    "sourceAttachmentId" text,
    "groupId" text,
    version integer DEFAULT 1 NOT NULL,
    "isCurrent" boolean DEFAULT true NOT NULL,
    status public."BoqStatus" DEFAULT 'DRAFT'::public."BoqStatus" NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_verification_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id text NOT NULL,
    category public."ExpenseCategory" NOT NULL,
    description text NOT NULL,
    amount double precision NOT NULL,
    "expenseDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "projectId" text,
    "vendorId" text,
    status public."ExpenseStatus" DEFAULT 'UNPAID'::public."ExpenseStatus" NOT NULL,
    notes text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: goods_receipt_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipt_items (
    id text NOT NULL,
    "goodsReceiptId" text NOT NULL,
    "purchaseOrderItemId" text NOT NULL,
    "quantityReceived" double precision NOT NULL,
    remarks text
);


--
-- Name: goods_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goods_receipts (
    id text NOT NULL,
    "purchaseOrderId" text NOT NULL,
    "receivedDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    remarks text,
    "receivedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: historical_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historical_rates (
    id text NOT NULL,
    category public."HistoricalRateCategory" NOT NULL,
    "itemName" text NOT NULL,
    unit text NOT NULL,
    rate double precision NOT NULL,
    location text,
    "effectiveDate" timestamp(3) without time zone NOT NULL,
    "sourceTenderId" text,
    notes text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "projectId" text,
    "sourceBillId" text,
    "clientName" text NOT NULL,
    subtotal double precision NOT NULL,
    "gstPercent" double precision DEFAULT 18 NOT NULL,
    "gstAmount" double precision NOT NULL,
    "totalAmount" double precision NOT NULL,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    "invoiceDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dueDate" timestamp(3) without time zone,
    notes text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text,
    "entityType" text,
    "entityId" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: organization_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_contacts (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    name text NOT NULL,
    designation text,
    email text,
    phone text,
    "isPrimary" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id text NOT NULL,
    name text NOT NULL,
    type public."OrganizationType" NOT NULL,
    address text,
    city text,
    state text,
    pincode text,
    "gstNumber" text,
    website text,
    notes text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id text NOT NULL,
    direction public."PaymentDirection" NOT NULL,
    amount double precision NOT NULL,
    "paymentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    method public."PaymentMethod" NOT NULL,
    "bankAccountId" text,
    "referenceNumber" text,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    remarks text,
    "recordedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id text NOT NULL,
    resource text NOT NULL,
    action text NOT NULL,
    key text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: project_bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_bills (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "billNumber" text NOT NULL,
    "billDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "cumulativeAmount" double precision NOT NULL,
    "currentBillAmount" double precision NOT NULL,
    status public."BillStatus" DEFAULT 'DRAFT'::public."BillStatus" NOT NULL,
    remarks text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: project_labor_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_labor_entries (
    id text NOT NULL,
    "projectId" text NOT NULL,
    category public."LaborCategory" NOT NULL,
    description text NOT NULL,
    "workerCount" integer NOT NULL,
    units double precision NOT NULL,
    "ratePerUnit" double precision NOT NULL,
    amount double precision NOT NULL,
    "entryDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    remarks text,
    "recordedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: project_material_usages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_material_usages (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "boqItemId" text,
    "materialName" text NOT NULL,
    unit text,
    "quantityUsed" double precision NOT NULL,
    "usageDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    remarks text,
    "recordedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: project_milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_milestones (
    id text NOT NULL,
    "projectId" text NOT NULL,
    title text NOT NULL,
    "plannedDate" timestamp(3) without time zone,
    "completedDate" timestamp(3) without time zone,
    status public."MilestoneStatus" DEFAULT 'PENDING'::public."MilestoneStatus" NOT NULL,
    "weightPercent" double precision DEFAULT 0 NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    "tenderId" text NOT NULL,
    name text NOT NULL,
    status public."ProjectStatus" DEFAULT 'ACTIVE'::public."ProjectStatus" NOT NULL,
    budget double precision NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "actualEndDate" timestamp(3) without time zone,
    location text,
    notes text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_items (
    id text NOT NULL,
    "purchaseOrderId" text NOT NULL,
    description text NOT NULL,
    unit text,
    quantity double precision NOT NULL,
    rate double precision NOT NULL,
    amount double precision NOT NULL,
    "receivedQuantity" double precision DEFAULT 0 NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    "poNumber" text NOT NULL,
    "vendorId" text NOT NULL,
    "tenderId" text,
    "sourceRfqId" text,
    status public."PurchaseOrderStatus" DEFAULT 'DRAFT'::public."PurchaseOrderStatus" NOT NULL,
    "expectedDeliveryDate" timestamp(3) without time zone,
    notes text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    family text NOT NULL,
    "deviceInfo" text,
    "ipAddress" text,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "replacedByTokenHash" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: rfq_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfq_items (
    id text NOT NULL,
    "rfqId" text NOT NULL,
    "boqItemId" text,
    description text NOT NULL,
    unit text,
    quantity double precision NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


--
-- Name: rfq_quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfq_quotes (
    id text NOT NULL,
    "rfqItemId" text NOT NULL,
    "vendorId" text NOT NULL,
    rate double precision NOT NULL,
    remarks text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: rfq_vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfq_vendors (
    id text NOT NULL,
    "rfqId" text NOT NULL,
    "vendorId" text NOT NULL,
    status public."RfqVendorStatus" DEFAULT 'INVITED'::public."RfqVendorStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: rfqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfqs (
    id text NOT NULL,
    "tenderId" text,
    title text NOT NULL,
    status public."RfqStatus" DEFAULT 'DRAFT'::public."RfqStatus" NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "awardedVendorId" text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isSystem" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id text NOT NULL,
    name text NOT NULL,
    color text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tender_assignees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tender_assignees (
    id text NOT NULL,
    "tenderId" text NOT NULL,
    "userId" text NOT NULL,
    role public."TenderAssigneeRole" DEFAULT 'OTHER'::public."TenderAssigneeRole" NOT NULL,
    "assignedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tender_competitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tender_competitors (
    id text NOT NULL,
    "tenderId" text NOT NULL,
    "competitorName" text NOT NULL,
    "bidAmount" double precision,
    "isWinningBid" boolean DEFAULT false NOT NULL,
    remarks text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tender_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tender_tags (
    id text NOT NULL,
    "tenderId" text NOT NULL,
    "tagId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tenders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenders (
    id text NOT NULL,
    "tenderNumber" text NOT NULL,
    title text NOT NULL,
    department text NOT NULL,
    "clientId" text NOT NULL,
    type text NOT NULL,
    category text NOT NULL,
    location text NOT NULL,
    state text NOT NULL,
    "estimatedCost" double precision NOT NULL,
    "emdAmount" double precision,
    "tenderFee" double precision,
    "documentFee" double precision,
    "submissionDate" timestamp(3) without time zone NOT NULL,
    "openingDate" timestamp(3) without time zone,
    "validityPeriodDays" integer,
    status public."TenderStatus" DEFAULT 'DRAFT'::public."TenderStatus" NOT NULL,
    "statusChangedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    priority public."TenderPriority" DEFAULT 'MEDIUM'::public."TenderPriority" NOT NULL,
    description text,
    remarks text,
    "winnerName" text,
    "winningBidAmount" double precision,
    "lossReason" text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    phone text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isEmailVerified" boolean DEFAULT false NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "createdById" text,
    "roleId" text NOT NULL,
    "avatarAttachmentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: vendor_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_contacts (
    id text NOT NULL,
    "vendorId" text NOT NULL,
    name text NOT NULL,
    designation text,
    email text,
    phone text,
    "isPrimary" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: vendor_ratings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_ratings (
    id text NOT NULL,
    "vendorId" text NOT NULL,
    "purchaseOrderId" text NOT NULL,
    rating integer NOT NULL,
    remarks text,
    "ratedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id text NOT NULL,
    name text NOT NULL,
    category public."VendorCategory" NOT NULL,
    "gstNumber" text,
    "panNumber" text,
    address text,
    city text,
    state text,
    "bankAccountName" text,
    "bankAccountNumber" text,
    "bankIfscCode" text,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
ca402849-598c-4089-b66d-40f628cdbec3	9f67dcc91f1b1d4ece8e0e3f4e2dda624ace76723fa1d3ee497d203ee357955d	2026-07-04 05:55:27.473198+00	20260704055527_init	\N	\N	2026-07-04 05:55:27.418964+00	1
32377f8d-fe5c-4f9e-a112-936b63457697	632f600c2efcecdc3b1f7772a66d7fce6405a76210ba74d7f19a47cc2a135188	2026-07-04 06:24:49.593462+00	20260704062449_phase2_tenders	\N	\N	2026-07-04 06:24:49.53781+00	1
2554ea5a-62dd-48a5-926d-71031ec96d69	82b75ee550c41e22ea8a2aac1aa76e68c332c9a0447f539abca1ed468a801225	2026-07-04 12:32:44.446313+00	20260704123244_phase3_boq_estimation	\N	\N	2026-07-04 12:32:44.414224+00	1
58d51457-f8db-42ca-ab08-5bd0c458b050	2b0b887b939b7d73315ac90b423638178a5f3b61570d8d0f3d93442c67515eda	2026-07-04 13:21:32.900675+00	20260704132132_phase4_procurement	\N	\N	2026-07-04 13:21:32.832826+00	1
660c07a4-cc77-41af-8e05-ff780aab2da8	2c99511f707bd99c6ba6d6520824b43c5c921e47dc1ce0de2bfddcd1dfa62f72	2026-07-04 13:28:24.316369+00	20260704132824_phase4_rfq_vendor_relations	\N	\N	2026-07-04 13:28:24.308116+00	1
1bb2fc14-9310-4922-825f-a58ebf6cbf4e	8810423d8c4e257bdc6eb1115b69ead88bae6a8060ef7ef223fcc12361f5aece	2026-07-04 14:06:39.512245+00	20260704140639_phase5_project_execution	\N	\N	2026-07-04 14:06:39.474816+00	1
260af400-e5dd-427e-8a21-fb7343bde27f	9dfedc26376009b7e6faced3536ea048e639e13b96af57dc099b62275a7541d7	2026-07-04 14:30:54.556503+00	20260704143054_phase6_finance	\N	\N	2026-07-04 14:30:54.531159+00	1
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, "originalName", "storedName", "mimeType", "sizeBytes", hash, "storageBucket", "storagePath", "entityType", "entityId", variant, "parentId", version, "uploadedById", "createdAt", "updatedAt", "documentGroupId", "documentType", "isCurrent") FROM stdin;
75fbd89b-5a13-423a-b737-a30f732f41d4	test-avatar.png	fea8b750-2b24-4205-9c6b-1bbfb74243cb-original.webp	image/webp	156	eb082ce5143243124b386b3010c1bfdb6442bfafbd947a26255375e417848390	bmp-attachments	user/4657478c-787b-4192-bf46-7a954fc9bc17/fea8b750-2b24-4205-9c6b-1bbfb74243cb-original.webp	User	4657478c-787b-4192-bf46-7a954fc9bc17	ORIGINAL	\N	1	4657478c-787b-4192-bf46-7a954fc9bc17	2026-07-04 05:58:41.687	2026-07-04 05:58:41.687	\N	\N	t
b668143c-6364-438a-a60a-352152072f79	test-avatar.png	2dafbb02-06eb-4d3a-9936-49f6bd3ef3bd-thumb.webp	image/webp	120	df0d0bf91ee22460adb65bdbcb1c043df29e33906e6832dad3e5196adf62a2fb	bmp-attachments	user/4657478c-787b-4192-bf46-7a954fc9bc17/2dafbb02-06eb-4d3a-9936-49f6bd3ef3bd-thumb.webp	User	4657478c-787b-4192-bf46-7a954fc9bc17	THUMBNAIL	75fbd89b-5a13-423a-b737-a30f732f41d4	1	4657478c-787b-4192-bf46-7a954fc9bc17	2026-07-04 05:58:41.722	2026-07-04 05:58:41.722	\N	\N	t
81732c14-4b2a-4db1-8920-0340d9f2c649	test-avatar.png	3f85a3d5-942a-4956-ab61-474a80da8d95-original.png	image/png	592	bd62514d50c86b1302ae086ee0fee39621c8aa816167a52c8f8fb4315d830e05	bmp-attachments	tender/0ea4ad05-a66a-4856-b0db-533d61b08b20/3f85a3d5-942a-4956-ab61-474a80da8d95-original.png	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	ORIGINAL	\N	1	80831d57-c57c-4d5e-bb18-f22e8a782664	2026-07-04 12:08:43.251	2026-07-04 12:08:43.26	81732c14-4b2a-4db1-8920-0340d9f2c649	DRAWINGS	t
70af94b3-b2c2-4bd1-bf57-5abb5f54a108	boq-fixture.xlsx	5547ace7-4813-4645-bfd3-21326041b9bf-original.xlsx	application/vnd.openxmlformats-officedocument.spreadsheetml.sheet	6682	4d458f31648b6d3324b5213ce22a609324d49471f2f418fef69a3388e7e2ac75	bmp-attachments	tender/0ea4ad05-a66a-4856-b0db-533d61b08b20/5547ace7-4813-4645-bfd3-21326041b9bf-original.xlsx	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	ORIGINAL	\N	1	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	2026-07-04 13:08:13.263	2026-07-04 13:08:13.275	70af94b3-b2c2-4bd1-bf57-5abb5f54a108	BOQ	t
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, "actorId", action, "entityType", "entityId", metadata, "ipAddress", "userAgent", "createdAt") FROM stdin;
850f878e-40c4-4210-a795-5714ab7cc73a	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	curl/8.7.1	2026-07-04 05:58:00.524
5d0098f2-4bbe-48ac-8f6a-9a602c261189	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	curl/8.7.1	2026-07-04 05:58:10.765
d428bd43-ba3f-40e5-857b-5bb9cdf183e3	d07c5c47-66e7-4331-85cd-a0aeb5171e1b	AUTH_LOGIN_SUCCESS	User	d07c5c47-66e7-4331-85cd-a0aeb5171e1b	\N	::1	curl/8.7.1	2026-07-04 05:58:24.886
85cd6c2c-1f74-40bb-942c-faa3de14693e	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	curl/8.7.1	2026-07-04 05:58:41.576
36d375d5-44f9-4d43-b232-e62d64afe60a	4657478c-787b-4192-bf46-7a954fc9bc17	USER_AVATAR_UPDATED	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	\N	\N	2026-07-04 05:58:41.733
32e04ae3-a6c9-4c17-8b6a-1de4e794c372	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	curl/8.7.1	2026-07-04 05:58:52.973
214e4240-18c3-410b-9b73-87a791aabb64	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	curl/8.7.1	2026-07-04 05:59:02.805
b183e8e6-108a-40bc-8867-a85881044268	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	curl/8.7.1	2026-07-04 05:59:17.497
d4c4647e-b536-449f-a9d8-f95a62c8f3d6	4657478c-787b-4192-bf46-7a954fc9bc17	USER_CREATED	User	cf024df1-0ac1-4dc1-8076-2be4a0be22e8	\N	::1	curl/8.7.1	2026-07-04 05:59:17.806
a6383cef-aa4e-4687-a50d-b50e58d8dfe0	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 06:02:06.153
5ca755bf-6fa6-4d41-b2f6-7fbbced8eef0	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 06:03:15.948
30588faf-2c13-4a76-aa70-cf25b5389a2a	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGOUT	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	\N	\N	2026-07-04 06:03:23.465
5d7ef559-b332-4df7-9c94-22c7e30e773a	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	2026-07-04 06:06:45.869
d8733ecd-2a80-481f-a8e3-f98b98b15ef0	4657478c-787b-4192-bf46-7a954fc9bc17	USER_UPDATED	User	cf024df1-0ac1-4dc1-8076-2be4a0be22e8	{"phone": "", "lastName": "Hire", "firstName": "New"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	2026-07-04 06:07:39.61
38586f71-9503-4815-b776-a60197e9a399	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	curl/8.7.1	2026-07-04 12:08:17.343
ecfe4c60-c2cb-4ccf-a4eb-0653c8ad6222	80831d57-c57c-4d5e-bb18-f22e8a782664	ORGANIZATION_CREATED	Organization	a3f2e69d-dab0-424c-89b6-8c683fb34750	\N	::1	curl/8.7.1	2026-07-04 12:08:17.394
e95cd5b3-6eb8-405f-8cf4-78837cb8480f	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_CREATED	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	\N	::1	curl/8.7.1	2026-07-04 12:08:17.497
ce0eb2cc-41f0-4380-b02f-342b64fc447d	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	curl/8.7.1	2026-07-04 12:08:43.121
b4b56975-bb56-470c-933f-a5dcdbb3db0d	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_DOCUMENT_UPLOADED	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	{"version": 1, "attachmentId": "81732c14-4b2a-4db1-8920-0340d9f2c649", "documentType": "DRAWINGS"}	\N	\N	2026-07-04 12:08:43.262
1afc7817-7fea-4c6c-b874-f5bf8ee1352a	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_ASSIGNED	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	{"role": "ESTIMATOR", "userId": "ccb330ec-0b2b-4a95-8fcd-a3c7793a50de"}	\N	\N	2026-07-04 12:08:43.309
92c80484-6dd0-424f-94e3-835883c2c401	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	{"to": "UPCOMING", "from": "DRAFT", "remarks": "Confirmed with department"}	::1	curl/8.7.1	2026-07-04 12:08:43.352
d7baa571-0bf8-4bca-9c1e-fd9f92cc8c11	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	curl/8.7.1	2026-07-04 12:09:06.064
fb1a06ca-ff48-47f7-bbf9-3076574837cb	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	AUTH_LOGIN_SUCCESS	User	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	\N	::1	curl/8.7.1	2026-07-04 12:11:53.147
1adb3542-84e8-4868-a4d5-ff3455386464	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	curl/8.7.1	2026-07-04 12:11:53.439
16a9a73f-c704-4b6d-a9c6-17cb260ecee4	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 12:12:43.031
1df7699c-36ea-4c23-8e9e-f04b68de9d99	d07c5c47-66e7-4331-85cd-a0aeb5171e1b	AUTH_LOGIN_SUCCESS	User	d07c5c47-66e7-4331-85cd-a0aeb5171e1b	\N	::1	curl/8.7.1	2026-07-04 12:14:53.456
97dbe2da-0c9a-47b8-b4a0-f9c1c38b60c2	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	AUTH_LOGIN_SUCCESS	User	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	\N	::1	curl/8.7.1	2026-07-04 12:14:53.815
ab04af0d-510f-4469-bfdd-98e197a54880	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	AUTH_LOGIN_SUCCESS	User	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:08:03.441
5545b467-2508-4a27-b73e-13c4373b9811	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	BOQ_COMMITTED	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	{"boqId": "a8b8c72d-5900-467b-879f-497a42b932cd", "version": 1, "ipAddress": "::1", "itemCount": 4, "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36"}	\N	\N	2026-07-04 13:08:14.008
6698b10b-5e30-475e-9842-3c791b5b51bf	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	BOQ_ITEM_UPDATED	BoqItem	579edb24-609b-43bb-8dd8-8ec33b88b708	{"boqId": "a8b8c72d-5900-467b-879f-497a42b932cd", "changes": {"rate": 999}}	\N	\N	2026-07-04 13:08:14.672
e4a48049-c6ae-4602-93b6-36302b5508e8	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	BOQ_ITEMS_BULK_UPDATED	BoqItem	a8b8c72d-5900-467b-879f-497a42b932cd	{"itemIds": ["579edb24-609b-43bb-8dd8-8ec33b88b708"], "ratePercentAdjustment": 10}	\N	\N	2026-07-04 13:08:15.9
5b277d04-8dc1-4058-9138-ae7d6357bb9f	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	BOQ_ITEM_RATE_ANALYSIS_UPDATED	BoqItem	579edb24-609b-43bb-8dd8-8ec33b88b708	{"boqId": "a8b8c72d-5900-467b-879f-497a42b932cd", "computedRate": 100}	\N	\N	2026-07-04 13:08:17.203
7fb01008-06e5-499e-ab7c-6986dd4b4a48	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	AUTH_LOGIN_SUCCESS	User	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:53:02.965
8fd6d7f7-4ac5-416a-8205-7e0ea98c0927	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	AUTH_LOGIN_SUCCESS	User	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:53:54.828
493f43ff-d4b1-48a0-925d-50623ac681b6	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_CREATED	Vendor	4b85c12e-acf8-4c31-bf3b-d642dac48829	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:53:56.417
2dcd4977-1a4c-470c-a25c-10206978ead0	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_CREATED	Rfq	5108731b-705b-425d-9fad-9b0133a5c745	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:54:02.25
f9d73687-ade6-4d71-95a2-7467bdd6f231	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	AUTH_LOGIN_SUCCESS	User	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:55:41.458
a85c40d9-93ad-494c-b88f-ee97afd1211c	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_CREATED	Vendor	1f426128-184c-4ea6-9e51-c9423c9b42b1	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:55:42.969
0635b829-431a-4531-8f14-1b8b643ae663	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_CREATED	Rfq	b0f1ab83-ffaf-43ee-b16e-2ce7d5136520	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:55:45.925
22f4d3d3-e7be-4820-a270-d74982a21de9	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_QUOTE_RECORDED	Rfq	b0f1ab83-ffaf-43ee-b16e-2ce7d5136520	{"rate": 375, "vendorId": "1f426128-184c-4ea6-9e51-c9423c9b42b1", "rfqItemId": "0fe1e9db-b6ea-4f36-83d0-78072b88b927"}	\N	\N	2026-07-04 13:55:46.208
33d65468-3af5-42e1-9900-60b1d393ff60	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	AUTH_LOGIN_SUCCESS	User	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:57:17.621
6711dcbf-14ca-4d33-b53d-1fea6e4bc2d8	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_CREATED	Vendor	4f875c54-54af-4b9e-85f3-dc174bbaeb0f	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:57:19.18
0de783b8-c2db-4f66-a572-c588e2c306a8	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_CREATED	Rfq	b1cf2105-6410-47a5-a6ef-23970139b5ee	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:57:23.329
5f9bc662-c22b-4b58-bfb7-c6ae7ebd304a	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_QUOTE_RECORDED	Rfq	b1cf2105-6410-47a5-a6ef-23970139b5ee	{"rate": 375, "vendorId": "4f875c54-54af-4b9e-85f3-dc174bbaeb0f", "rfqItemId": "b005e930-f88d-47dd-aef1-c4e505fccdd3"}	\N	\N	2026-07-04 13:57:24.021
ca66088a-c94c-403d-9429-87d7a94df7c8	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	AUTH_LOGIN_SUCCESS	User	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:58:19.292
7b8e6f9e-e7a2-4b0d-abfc-80542a598ea3	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_CREATED	Vendor	c5220ab5-06fe-4307-9cea-95c60a3e3cd1	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:58:20.668
5dda08c5-c9c5-4310-8952-a1bbed0b327f	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_CREATED	Rfq	233ffe5d-f739-4121-93d1-b4819f678591	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 13:58:23.476
81a68e03-d562-4d1b-be43-d3698582be5d	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_QUOTE_RECORDED	Rfq	233ffe5d-f739-4121-93d1-b4819f678591	{"rate": 375, "vendorId": "c5220ab5-06fe-4307-9cea-95c60a3e3cd1", "rfqItemId": "b57e06bf-5f67-4cff-bcbf-aa8662aaa059"}	\N	\N	2026-07-04 13:58:23.725
292d8ccb-0673-46b4-a7ec-2103946ac8e9	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	AUTH_LOGIN_SUCCESS	User	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:00:53.187
93f4cca4-664d-4d5b-bf64-df39139b1d6c	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_CREATED	Vendor	f9551d89-b587-43a1-867c-040650349875	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:00:57.005
3f83026a-c847-4012-9343-98a82f45503c	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_CREATED	Rfq	d437c0fc-4878-4909-a379-f40897d2b686	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:01:02.283
fd584ad9-4665-48b0-9f16-7e47642ce710	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_QUOTE_RECORDED	Rfq	d437c0fc-4878-4909-a379-f40897d2b686	{"rate": 375, "vendorId": "f9551d89-b587-43a1-867c-040650349875", "rfqItemId": "c900fed5-dd35-448e-9a03-98ca5d9ea892"}	\N	\N	2026-07-04 14:01:03.695
8e84f4cb-cb4c-429a-86ab-0f9101b2502c	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_AWARDED	Rfq	d437c0fc-4878-4909-a379-f40897d2b686	{"vendorId": "f9551d89-b587-43a1-867c-040650349875"}	\N	\N	2026-07-04 14:01:05.622
dd1fa770-6d43-457b-95e6-6005f531d4fe	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	PURCHASE_ORDER_CREATED_FROM_RFQ	PurchaseOrder	b6828c4c-f8d6-4f34-bdf3-a1222de46533	{"rfqId": "d437c0fc-4878-4909-a379-f40897d2b686"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:01:06.483
46499686-2a83-4ab8-af14-91f9a32a6288	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	PURCHASE_ORDER_ISSUED	PurchaseOrder	b6828c4c-f8d6-4f34-bdf3-a1222de46533	\N	\N	\N	2026-07-04 14:01:07.919
fca12914-d18a-447d-bbad-9008b5473112	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	GOODS_RECEIPT_RECORDED	PurchaseOrder	b6828c4c-f8d6-4f34-bdf3-a1222de46533	{"items": [{"quantityReceived": 200, "purchaseOrderItemId": "ce6a2544-5a98-4375-8d01-096de8cfaae5"}]}	\N	\N	2026-07-04 14:01:08.986
882ecaed-75a7-41e4-9f20-e733a5d64d0d	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	GOODS_RECEIPT_RECORDED	PurchaseOrder	b6828c4c-f8d6-4f34-bdf3-a1222de46533	{"items": [{"quantityReceived": 300, "purchaseOrderItemId": "ce6a2544-5a98-4375-8d01-096de8cfaae5"}]}	\N	\N	2026-07-04 14:01:10.044
7d8702b8-3790-4856-9cf7-8582c86310ed	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_RATED	PurchaseOrder	b6828c4c-f8d6-4f34-bdf3-a1222de46533	{"rating": 5, "vendorId": "f9551d89-b587-43a1-867c-040650349875"}	\N	\N	2026-07-04 14:01:10.928
560af2f1-0507-4d13-9c17-514304ddb62f	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	AUTH_LOGIN_SUCCESS	User	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:02:10.016
eed61e12-aa01-4042-980e-cdb462187b43	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_CREATED	Vendor	d0df4401-c24f-4d84-bce6-01686a8fadac	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:02:11.442
ebb393cb-8919-45ea-89d1-13e018373640	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_CREATED	Rfq	fc9b863f-70c9-4aa8-b835-69a6dfff8630	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:02:14.131
a22d27dc-11f8-4ce6-bfc3-b3e0fb15830a	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_QUOTE_RECORDED	Rfq	fc9b863f-70c9-4aa8-b835-69a6dfff8630	{"rate": 375, "vendorId": "d0df4401-c24f-4d84-bce6-01686a8fadac", "rfqItemId": "455eb987-fc1e-46ab-9623-f37842a87c4b"}	\N	\N	2026-07-04 14:02:14.382
0839d974-959e-432e-8dab-b542d729f9eb	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	RFQ_AWARDED	Rfq	fc9b863f-70c9-4aa8-b835-69a6dfff8630	{"vendorId": "d0df4401-c24f-4d84-bce6-01686a8fadac"}	\N	\N	2026-07-04 14:02:16.273
3d8833d1-458f-4d6d-aa3d-f55c6a73afd5	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	PURCHASE_ORDER_CREATED_FROM_RFQ	PurchaseOrder	17974ee2-ff59-40f1-90fa-022a968c79d4	{"rfqId": "fc9b863f-70c9-4aa8-b835-69a6dfff8630"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:02:17.121
8e9d00a1-e75e-4197-8adf-64b6173cbf99	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	PURCHASE_ORDER_ISSUED	PurchaseOrder	17974ee2-ff59-40f1-90fa-022a968c79d4	\N	\N	\N	2026-07-04 14:02:17.34
a4435df1-3278-46db-b240-693b7d29cdd0	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	GOODS_RECEIPT_RECORDED	PurchaseOrder	17974ee2-ff59-40f1-90fa-022a968c79d4	{"items": [{"quantityReceived": 200, "purchaseOrderItemId": "b4b047c6-6298-4732-b26c-aa9e3b089dba"}]}	\N	\N	2026-07-04 14:02:18.418
d022afac-f167-4bb9-aaa8-4c08478941e8	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	GOODS_RECEIPT_RECORDED	PurchaseOrder	17974ee2-ff59-40f1-90fa-022a968c79d4	{"items": [{"quantityReceived": 300, "purchaseOrderItemId": "b4b047c6-6298-4732-b26c-aa9e3b089dba"}]}	\N	\N	2026-07-04 14:02:19.466
7d3abef1-e6f5-4257-8a23-d3cde67dcde8	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	VENDOR_RATED	PurchaseOrder	17974ee2-ff59-40f1-90fa-022a968c79d4	{"rating": 5, "vendorId": "d0df4401-c24f-4d84-bce6-01686a8fadac"}	\N	\N	2026-07-04 14:02:20.339
abb0b5ce-3fa9-49d8-bd3c-51745ddba6dc	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	node	2026-07-04 14:23:45.109
5c878e24-6321-4420-a535-3f9dac77031b	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_CREATED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	\N	::1	node	2026-07-04 14:23:45.165
4acbfe61-efee-4739-9018-1e119c16f15c	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "UPCOMING", "from": "DRAFT", "remarks": null}	::1	node	2026-07-04 14:23:45.177
b5b3a56c-90f8-42c3-979e-a07b978308c2	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "DOCUMENT_COLLECTION", "from": "UPCOMING", "remarks": null}	::1	node	2026-07-04 14:23:45.186
40a5cd90-a992-4f64-b533-1d2ca810f691	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "UNDER_STUDY", "from": "DOCUMENT_COLLECTION", "remarks": null}	::1	node	2026-07-04 14:23:45.195
45199aa7-e2ea-432c-9339-df4f316146a8	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "BOQ_PREPARATION", "from": "UNDER_STUDY", "remarks": null}	::1	node	2026-07-04 14:23:45.203
bdf560ad-c168-4119-87b5-8fd10a03c72e	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "RATE_ANALYSIS", "from": "BOQ_PREPARATION", "remarks": null}	::1	node	2026-07-04 14:23:45.213
1639dd79-bc7b-42e2-bfc3-ccc5f8998897	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "APPROVAL_PENDING", "from": "RATE_ANALYSIS", "remarks": null}	::1	node	2026-07-04 14:23:45.223
3b7072f9-ee64-4497-ac21-59dfd62c211e	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "SUBMITTED", "from": "APPROVAL_PENDING", "remarks": null}	::1	node	2026-07-04 14:23:45.233
1143aef1-d1b6-48d1-afe5-1a865595e717	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "TECHNICALLY_QUALIFIED", "from": "SUBMITTED", "remarks": null}	::1	node	2026-07-04 14:23:45.241
67ec2c5c-8ba4-4aa9-ba5b-8e1c399dd82e	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "FINANCIALLY_QUALIFIED", "from": "TECHNICALLY_QUALIFIED", "remarks": null}	::1	node	2026-07-04 14:23:45.252
84a96042-6995-4682-a617-f59a1eb532c4	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	f2e13ccb-39c4-4fdb-b71e-527781f118f8	{"to": "WON", "from": "FINANCIALLY_QUALIFIED", "remarks": null}	::1	node	2026-07-04 14:23:45.261
ae85b287-f63c-4736-991c-f08238c7939f	9125a4ce-5438-40ef-a999-2cb595ed4156	AUTH_LOGIN_SUCCESS	User	9125a4ce-5438-40ef-a999-2cb595ed4156	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:23:47.424
af55bd65-c346-43ae-bf42-7c1c511b730a	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_CREATED_FROM_TENDER	Project	b5b28471-e9b1-416c-a776-a13716dc3bcc	{"tenderId": "f2e13ccb-39c4-4fdb-b71e-527781f118f8"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:23:52.538
ec6bb8f5-2635-43f0-a970-39095fd067b3	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	node	2026-07-04 14:24:58.648
2a39d496-aaa4-4274-bc26-f5c68a816273	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_CREATED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	\N	::1	node	2026-07-04 14:24:58.682
c0b98814-4b9a-469e-ac2c-dab8bc33b711	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "UPCOMING", "from": "DRAFT", "remarks": null}	::1	node	2026-07-04 14:24:58.694
ea6d213a-d51a-42cd-af95-77b82298fa51	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "DOCUMENT_COLLECTION", "from": "UPCOMING", "remarks": null}	::1	node	2026-07-04 14:24:58.703
77c64dbe-b73f-45a0-a114-4e6a35cc1bb0	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "UNDER_STUDY", "from": "DOCUMENT_COLLECTION", "remarks": null}	::1	node	2026-07-04 14:24:58.711
c9701e0a-d87a-45fc-9aaa-562f5768e47c	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "BOQ_PREPARATION", "from": "UNDER_STUDY", "remarks": null}	::1	node	2026-07-04 14:24:58.72
17d11928-d2c7-40c4-9fca-689b40977de7	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "RATE_ANALYSIS", "from": "BOQ_PREPARATION", "remarks": null}	::1	node	2026-07-04 14:24:58.728
cdcc8bd4-24a8-41cd-9ea7-b56aa7e06980	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "APPROVAL_PENDING", "from": "RATE_ANALYSIS", "remarks": null}	::1	node	2026-07-04 14:24:58.736
b428cbaa-19f3-4a97-82cc-9b2750fd548c	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "SUBMITTED", "from": "APPROVAL_PENDING", "remarks": null}	::1	node	2026-07-04 14:24:58.745
1efb444c-5c06-4e56-abef-97f85bff741c	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "TECHNICALLY_QUALIFIED", "from": "SUBMITTED", "remarks": null}	::1	node	2026-07-04 14:24:58.753
f68b0a38-946e-46ec-a742-85adf87618da	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "FINANCIALLY_QUALIFIED", "from": "TECHNICALLY_QUALIFIED", "remarks": null}	::1	node	2026-07-04 14:24:58.76
9009c575-ead5-4a64-b537-a3ff4b96cd2b	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	a29ba86e-27be-4134-a8cb-43edeec828b4	{"to": "WON", "from": "FINANCIALLY_QUALIFIED", "remarks": null}	::1	node	2026-07-04 14:24:58.768
be482767-474f-4188-b6cc-5e476e204257	9125a4ce-5438-40ef-a999-2cb595ed4156	AUTH_LOGIN_SUCCESS	User	9125a4ce-5438-40ef-a999-2cb595ed4156	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:25:00.9
155ab388-5ba4-4a83-9596-0e44f3b7208b	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_MILESTONE_ADDED	Project	b5a82a94-6b39-44b9-b870-8e14448e3842	\N	\N	\N	2026-07-04 14:26:10.706
ffc964aa-ce70-47bc-aa12-7343b8830f6e	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_MILESTONE_UPDATED	Project	b5a82a94-6b39-44b9-b870-8e14448e3842	{"milestoneId": "d27c700c-0320-426c-ac8c-6a3377b07abb"}	\N	\N	2026-07-04 14:26:11.732
230a2b93-1b15-43ef-9512-729b761ec2a3	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_LABOR_ENTRY_RECORDED	Project	b5a82a94-6b39-44b9-b870-8e14448e3842	{"amount": 1600}	\N	\N	2026-07-04 14:26:13
4095812e-3c01-43d2-bac6-72bdc06cb9a2	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_BILL_CREATED	Project	b5a82a94-6b39-44b9-b870-8e14448e3842	{"billNumber": "RA-1", "currentBillAmount": 100000}	\N	\N	2026-07-04 14:26:14.199
fe3b6913-36ca-4f40-bb30-33a0564cca69	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_CREATED_FROM_TENDER	Project	e8dba173-1058-4f05-a05b-03c2f8206665	{"tenderId": "a29ba86e-27be-4134-a8cb-43edeec828b4"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:25:02.638
fe98eaae-4873-4f50-be3d-112eaab1d38d	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_MILESTONE_ADDED	Project	e8dba173-1058-4f05-a05b-03c2f8206665	\N	\N	\N	2026-07-04 14:25:03.105
6455da7d-ecfa-42b3-9b8c-6eaa8f95c5d2	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_MILESTONE_UPDATED	Project	e8dba173-1058-4f05-a05b-03c2f8206665	{"milestoneId": "289dc043-c019-44fa-a875-29ca4e7059ee"}	\N	\N	2026-07-04 14:25:04.109
ac75b56f-6d02-42a3-b91e-8c522f3b5ede	80831d57-c57c-4d5e-bb18-f22e8a782664	AUTH_LOGIN_SUCCESS	User	80831d57-c57c-4d5e-bb18-f22e8a782664	\N	::1	node	2026-07-04 14:26:06.462
1288a5d1-9d88-4579-b16c-d74a2c5bff41	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_CREATED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	\N	::1	node	2026-07-04 14:26:06.497
0a097a28-60c5-4723-a82a-0dcea3d2732b	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "UPCOMING", "from": "DRAFT", "remarks": null}	::1	node	2026-07-04 14:26:06.51
62957527-1942-42c3-872f-7227f577c907	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "DOCUMENT_COLLECTION", "from": "UPCOMING", "remarks": null}	::1	node	2026-07-04 14:26:06.52
cfeeb8e8-2507-4483-a4d0-16aec077e056	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "UNDER_STUDY", "from": "DOCUMENT_COLLECTION", "remarks": null}	::1	node	2026-07-04 14:26:06.529
e66490a4-a024-474f-baa5-3c757c820c29	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "BOQ_PREPARATION", "from": "UNDER_STUDY", "remarks": null}	::1	node	2026-07-04 14:26:06.539
dddf8556-ea14-498a-9e73-381dd2dc7ac6	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "RATE_ANALYSIS", "from": "BOQ_PREPARATION", "remarks": null}	::1	node	2026-07-04 14:26:06.548
8d14021f-56eb-4123-ba3b-edf69b6088aa	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "APPROVAL_PENDING", "from": "RATE_ANALYSIS", "remarks": null}	::1	node	2026-07-04 14:26:06.556
9ae65a72-9721-4483-af2f-bc6e5e4b6f22	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "SUBMITTED", "from": "APPROVAL_PENDING", "remarks": null}	::1	node	2026-07-04 14:26:06.566
17624023-a24a-4ab8-9f6e-b4e0a046806f	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "TECHNICALLY_QUALIFIED", "from": "SUBMITTED", "remarks": null}	::1	node	2026-07-04 14:26:06.574
7f5515e1-843a-44bd-a3d8-87ca8db3e7b8	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "FINANCIALLY_QUALIFIED", "from": "TECHNICALLY_QUALIFIED", "remarks": null}	::1	node	2026-07-04 14:26:06.581
79c1f2f7-b024-4991-81dd-a3a829a9b8db	80831d57-c57c-4d5e-bb18-f22e8a782664	TENDER_STATUS_CHANGED	Tender	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	{"to": "WON", "from": "FINANCIALLY_QUALIFIED", "remarks": null}	::1	node	2026-07-04 14:26:06.591
94edd39b-4c00-4fa9-b77c-835a6fee3ff9	9125a4ce-5438-40ef-a999-2cb595ed4156	AUTH_LOGIN_SUCCESS	User	9125a4ce-5438-40ef-a999-2cb595ed4156	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:26:08.568
a248caba-7fb8-4e36-8126-0ff838c0c51e	9125a4ce-5438-40ef-a999-2cb595ed4156	PROJECT_CREATED_FROM_TENDER	Project	b5a82a94-6b39-44b9-b870-8e14448e3842	{"tenderId": "1a779b72-7d03-4cef-9d38-fb3d189b2d2f"}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:26:10.252
73b06349-182a-4e93-aed9-035afe1ab001	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	AUTH_LOGIN_SUCCESS	User	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 14:51:03.149
21fb2419-99a2-4291-a1ad-0d05310bacbd	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	BANK_ACCOUNT_CREATED	BankAccount	d22c074d-29a7-4c37-8e0a-defffb4f1663	\N	\N	\N	2026-07-04 14:51:07.786
f89ac050-9f31-4514-a706-02b32a3681a1	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	INVOICE_CREATED	Invoice	89d4dcb7-7ddf-49a8-afd0-45fb1cfed975	\N	\N	\N	2026-07-04 14:51:08.985
b512bdbe-1026-473d-96e3-bcffe710eca9	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	PAYMENT_RECORDED	Invoice	89d4dcb7-7ddf-49a8-afd0-45fb1cfed975	{"amount": 50000, "direction": "RECEIVED"}	\N	\N	2026-07-04 14:51:11.038
47d87297-84e4-4c04-8e04-2b4899b36d90	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	PAYMENT_RECORDED	Invoice	89d4dcb7-7ddf-49a8-afd0-45fb1cfed975	{"amount": 68000, "direction": "RECEIVED"}	\N	\N	2026-07-04 14:51:11.991
45a5e34e-285e-433e-8cbf-9b1f84a4911c	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	EXPENSE_CREATED	Expense	3a33d4b9-f3e8-4db9-b6e5-fc1a8094614a	\N	\N	\N	2026-07-04 14:51:14.562
42a23f52-1aba-4d01-ab4f-13f817993e1c	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	PAYMENT_RECORDED	Expense	3a33d4b9-f3e8-4db9-b6e5-fc1a8094614a	{"amount": 2000, "direction": "PAID"}	\N	\N	2026-07-04 14:51:16.568
184a58b8-de7d-4299-bd64-6cd088f550a5	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 15:11:28.729
4f68407b-d9b6-4811-9016-c5904fab50d4	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	curl/8.7.1	2026-07-04 15:12:09.718
2142c826-693c-4221-a671-7b7575b5cc26	4657478c-787b-4192-bf46-7a954fc9bc17	AUTH_LOGIN_SUCCESS	User	4657478c-787b-4192-bf46-7a954fc9bc17	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	2026-07-04 15:12:27.449
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_accounts (id, name, "accountNumber", "bankName", "ifscCode", "openingBalance", "isActive", "createdById", "createdAt", "updatedAt") FROM stdin;
d22c074d-29a7-4c37-8e0a-defffb4f1663	HDFC Current 1783176667572	\N	\N	\N	10000	t	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	2026-07-04 14:51:07.781	2026-07-04 14:51:07.781
\.


--
-- Data for Name: boq_item_rate_breakdowns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.boq_item_rate_breakdowns (id, "boqItemId", "materialCost", "laborCost", "machineryCost", "transportCost", "overheadPercent", "profitPercent", "taxPercent", "computedRate", "updatedAt") FROM stdin;
9953cf66-e998-44f4-9d65-130ad5873a95	579edb24-609b-43bb-8dd8-8ec33b88b708	100	0	0	0	0	0	0	100	2026-07-04 13:08:17.195
\.


--
-- Data for Name: boq_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.boq_items (id, "boqId", "parentId", "itemCode", description, category, unit, quantity, rate, amount, remarks, "sortOrder", "createdAt", "updatedAt") FROM stdin;
16dd1979-cd54-4e27-89e8-0a7028ec4a29	a8b8c72d-5900-467b-879f-497a42b932cd	\N	1.2	Excavation for Foundation	Earthwork	cum	200	180	36000	\N	2	2026-07-04 13:08:13.993	2026-07-04 13:08:13.993
bd7c0593-84c8-4262-ae0e-55d21ed5fbc6	a8b8c72d-5900-467b-879f-497a42b932cd	\N	2.1	PCC 1:4:8	Concrete	cum	40	4500	180000	\N	3	2026-07-04 13:08:13.993	2026-07-04 13:08:13.993
29546da9-0236-47a6-8ae6-f285479763b4	a8b8c72d-5900-467b-879f-497a42b932cd	\N	2.2	RCC M25 for Footings	Concrete	cum	60	6200	372000	\N	4	2026-07-04 13:08:13.993	2026-07-04 13:08:13.993
579edb24-609b-43bb-8dd8-8ec33b88b708	a8b8c72d-5900-467b-879f-497a42b932cd	\N	1.1	Site Clearance	Earthwork	sqm	500	100	50000	\N	1	2026-07-04 13:08:13.993	2026-07-04 13:08:17.201
\.


--
-- Data for Name: boqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.boqs (id, "tenderId", "sourceAttachmentId", "groupId", version, "isCurrent", status, "createdById", "createdAt", "updatedAt") FROM stdin;
a8b8c72d-5900-467b-879f-497a42b932cd	0ea4ad05-a66a-4856-b0db-533d61b08b20	70af94b3-b2c2-4bd1-bf57-5abb5f54a108	a8b8c72d-5900-467b-879f-497a42b932cd	1	t	DRAFT	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	2026-07-04 13:08:13.993	2026-07-04 13:08:13.993
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_verification_tokens (id, "userId", "tokenHash", "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, category, description, amount, "expenseDate", "projectId", "vendorId", status, notes, "createdById", "createdAt", "updatedAt") FROM stdin;
3a33d4b9-f3e8-4db9-b6e5-fc1a8094614a	OTHER	Site office supplies	2000	2026-07-04 14:51:14.556	\N	\N	PAID	\N	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	2026-07-04 14:51:14.556	2026-07-04 14:51:16.57
\.


--
-- Data for Name: goods_receipt_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipt_items (id, "goodsReceiptId", "purchaseOrderItemId", "quantityReceived", remarks) FROM stdin;
0ba714df-de3b-4bab-91aa-ca271f7fdd9c	14483ad3-b962-46b9-b871-c1589a8a1929	ce6a2544-5a98-4375-8d01-096de8cfaae5	200	\N
2de78f03-647e-4611-b818-caf1994d0a7d	511a3320-4d9a-4fb1-9695-a54732035420	ce6a2544-5a98-4375-8d01-096de8cfaae5	300	\N
92a13d84-97b3-4d58-9921-ad8ba433079b	19fa7242-b117-402c-9031-2a60c8ea2cd7	b4b047c6-6298-4732-b26c-aa9e3b089dba	200	\N
3d382454-c400-4a26-8514-37417267d12d	73ba2d21-eae9-4162-b74b-36dbffb18897	b4b047c6-6298-4732-b26c-aa9e3b089dba	300	\N
\.


--
-- Data for Name: goods_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goods_receipts (id, "purchaseOrderId", "receivedDate", remarks, "receivedById", "createdAt") FROM stdin;
14483ad3-b962-46b9-b871-c1589a8a1929	b6828c4c-f8d6-4f34-bdf3-a1222de46533	2026-07-04 14:01:08.975	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:01:08.976
511a3320-4d9a-4fb1-9695-a54732035420	b6828c4c-f8d6-4f34-bdf3-a1222de46533	2026-07-04 14:01:10.036	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:01:10.036
19fa7242-b117-402c-9031-2a60c8ea2cd7	17974ee2-ff59-40f1-90fa-022a968c79d4	2026-07-04 14:02:18.407	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:02:18.408
73ba2d21-eae9-4162-b74b-36dbffb18897	17974ee2-ff59-40f1-90fa-022a968c79d4	2026-07-04 14:02:19.457	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:02:19.458
\.


--
-- Data for Name: historical_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.historical_rates (id, category, "itemName", unit, rate, location, "effectiveDate", "sourceTenderId", notes, "createdById", "createdAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, "invoiceNumber", "projectId", "sourceBillId", "clientName", subtotal, "gstPercent", "gstAmount", "totalAmount", status, "invoiceDate", "dueDate", notes, "createdById", "createdAt", "updatedAt") FROM stdin;
89d4dcb7-7ddf-49a8-afd0-45fb1cfed975	INV-P6-1783176668776	\N	\N	PWD Test Client	100000	18	18000	118000	PAID	2026-07-04 14:51:08.98	\N	\N	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	2026-07-04 14:51:08.98	2026-07-04 14:51:11.993
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, "userId", type, title, body, "entityType", "entityId", "isRead", "readAt", metadata, "createdAt") FROM stdin;
0e3256c8-cbd7-4a45-9010-71d7ed73daee	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	TENDER_ASSIGNED	You were assigned to tender TND-TEST-001	Road Widening Project	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	f	\N	\N	2026-07-04 12:08:43.298
58d3a117-3d61-43aa-9f26-03824c851e41	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	TENDER_STATUS_CHANGED	Tender TND-TEST-001 status changed to UPCOMING	Road Widening Project	Tender	0ea4ad05-a66a-4856-b0db-533d61b08b20	f	\N	{"to": "UPCOMING", "from": "DRAFT"}	2026-07-04 12:08:43.354
\.


--
-- Data for Name: organization_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_contacts (id, "organizationId", name, designation, email, phone, "isPrimary", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organizations (id, name, type, address, city, state, pincode, "gstNumber", website, notes, "createdById", "createdAt", "updatedAt") FROM stdin;
a3f2e69d-dab0-424c-89b6-8c683fb34750	Public Works Department	GOVERNMENT	\N	Mumbai	Maharashtra	\N	\N	\N	\N	80831d57-c57c-4d5e-bb18-f22e8a782664	2026-07-04 12:08:17.374	2026-07-04 12:08:17.374
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, "userId", "tokenHash", "expiresAt", "usedAt", "createdAt") FROM stdin;
3ad2b57f-fb0e-4488-931c-04fa8d1db984	cf024df1-0ac1-4dc1-8076-2be4a0be22e8	e508669c2f7b615cb2bb814086d9a3d5ddf50c23624f2bd45dd2a41dc127271d	2026-07-06 05:59:17.796	\N	2026-07-04 05:59:17.797
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, direction, amount, "paymentDate", method, "bankAccountId", "referenceNumber", "entityType", "entityId", remarks, "recordedById", "createdAt") FROM stdin;
aa83e859-19a1-4fbc-9d99-e0bc211a5ca2	RECEIVED	50000	2026-07-04 14:51:11.034	CASH	\N	\N	Invoice	89d4dcb7-7ddf-49a8-afd0-45fb1cfed975	\N	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	2026-07-04 14:51:11.034
ce1e66a3-4685-45b6-86ed-af21c613ec63	RECEIVED	68000	2026-07-04 14:51:11.988	CASH	\N	\N	Invoice	89d4dcb7-7ddf-49a8-afd0-45fb1cfed975	\N	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	2026-07-04 14:51:11.988
e06ad708-8053-459b-a0dc-d6c1a5156296	PAID	2000	2026-07-04 14:51:16.566	CASH	\N	\N	Expense	3a33d4b9-f3e8-4db9-b6e5-fc1a8094614a	\N	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	2026-07-04 14:51:16.566
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, resource, action, key, description, "createdAt") FROM stdin;
773972e0-9181-4e31-ad88-f99192e8f8ea	*	*	*:*	Full, unrestricted access to every resource and action	2026-07-04 05:55:36.887
93e4fb8f-8de1-4b90-9165-2a7fcd1b6e28	vendors	create	vendors:create	Permission to create vendors	2026-07-04 13:52:00.279
8ec2d510-1d10-485e-9f40-b48591df6c46	purchase_orders	read	purchase_orders:read	Permission to read purchase_orders	2026-07-04 13:52:00.288
b4c1d68b-30aa-4a41-b7fb-80aecfc0eeec	purchase_orders	update	purchase_orders:update	Permission to update purchase_orders	2026-07-04 13:52:00.289
094ea0d8-d090-477d-a376-8235654612fd	projects	read	projects:read	Permission to read projects	2026-07-04 14:22:04.916
0dfa511a-858c-4545-b58d-c9efb8699fc5	tenders	assign	tenders:assign	Permission to assign tenders	2026-07-04 12:06:33.461
e3698666-90f9-409a-ad10-6be2caf17772	tenders	change_status	tenders:change_status	Permission to change_status tenders	2026-07-04 12:06:33.462
e22ddc29-ea01-4700-af31-c433220b5696	organizations	create	organizations:create	Permission to create organizations	2026-07-04 12:06:33.463
21af72d5-a86d-4581-b4b9-000b9f514e10	organizations	update	organizations:update	Permission to update organizations	2026-07-04 12:06:33.464
0d16929e-3304-4ff8-a47b-a7fcc8f83a66	tags	update	tags:update	Permission to update tags	2026-07-04 12:06:33.467
2841b09b-e139-4027-965c-fa3d9d68ea29	tags	delete	tags:delete	Permission to delete tags	2026-07-04 12:06:33.467
d3190e77-6a27-49ba-845f-45012f755775	boq	create	boq:create	Permission to create boq	2026-07-04 13:02:31.066
6743dc73-207c-4b8d-a8a1-b95f953c7320	boq	delete	boq:delete	Permission to delete boq	2026-07-04 13:02:31.068
f3fe3a32-fe5f-4c59-8649-f2975cce3f09	rates	create	rates:create	Permission to create rates	2026-07-04 13:02:31.069
fd548a31-5f38-470f-85f4-4b1398e56889	users	assign_role	users:assign_role	Permission to assign_role users	2026-07-04 05:55:36.877
2dd273cf-5293-461a-9c5c-9dc057229a88	roles	read	roles:read	Permission to read roles	2026-07-04 05:55:36.878
40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	attachments	read	attachments:read	Permission to read attachments	2026-07-04 05:55:36.882
ea06f0c6-5a54-458b-8f67-f3b59da92bae	attachments	delete	attachments:delete	Permission to delete attachments	2026-07-04 05:55:36.883
1f4b4897-028d-4673-9023-848f4b50c436	audit	read	audit:read	Permission to read audit	2026-07-04 05:55:36.885
be7674ef-4883-4cdf-953b-e89af8666d7f	tenders	create	tenders:create	Permission to create tenders	2026-07-04 12:06:33.454
f9440996-a870-4896-950f-c42b56d3db5b	tenders	read	tenders:read	Permission to read tenders	2026-07-04 12:06:33.456
480c806b-1b01-4270-a3d7-565019b7d833	organizations	delete	organizations:delete	Permission to delete organizations	2026-07-04 12:06:33.465
6b0fd465-38af-45b5-8a72-099b415df7c7	tags	create	tags:create	Permission to create tags	2026-07-04 12:06:33.465
564b9586-841f-402d-bdc4-76df5f1a2914	tags	read	tags:read	Permission to read tags	2026-07-04 12:06:33.466
35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	boq	read	boq:read	Permission to read boq	2026-07-04 13:02:31.067
ed7d1c54-773c-40cd-a375-448dba78e74b	rates	read	rates:read	Permission to read rates	2026-07-04 13:02:31.07
63c6d2f9-aa54-4b4d-837f-5f7e7a6eed62	rates	update	rates:update	Permission to update rates	2026-07-04 13:02:31.07
299c030e-bbfd-4d7e-92f9-8a0ab8474793	vendors	read	vendors:read	Permission to read vendors	2026-07-04 13:52:00.281
ed205752-22c6-41be-a9c4-b33566d2b718	vendors	update	vendors:update	Permission to update vendors	2026-07-04 13:52:00.282
b310d589-5ade-4ea1-8707-7c1168458830	vendors	delete	vendors:delete	Permission to delete vendors	2026-07-04 13:52:00.284
8b07ea69-d484-48b8-8121-4c944410de4e	rfq	create	rfq:create	Permission to create rfq	2026-07-04 13:52:00.285
ab0e1dd4-458b-47b4-9bf1-676c477a895f	rfq	read	rfq:read	Permission to read rfq	2026-07-04 13:52:00.286
d62bdccb-1b51-405f-bcab-60738c4dcbb7	rfq	update	rfq:update	Permission to update rfq	2026-07-04 13:52:00.287
a6f2703a-9a4f-4a63-931e-5f3832e97434	purchase_orders	create	purchase_orders:create	Permission to create purchase_orders	2026-07-04 13:52:00.287
b035de9c-93ba-42e8-b392-1345807a4e32	purchase_orders	receive	purchase_orders:receive	Permission to receive purchase_orders	2026-07-04 13:52:00.289
f444dde3-0b40-4691-b7bf-c7b659366725	projects	create	projects:create	Permission to create projects	2026-07-04 14:22:04.915
5429cb5e-d339-4115-a5bf-f124f23267a4	permissions	read	permissions:read	Permission to read permissions	2026-07-04 05:55:36.879
8ced55ab-b7fb-4c14-89d1-8b1e48bcf5ef	attachments	create	attachments:create	Permission to create attachments	2026-07-04 05:55:36.88
9cc99df5-d416-4b73-8b5f-04a4627ef5fb	sessions	revoke_others	sessions:revoke_others	Permission to revoke_others sessions	2026-07-04 05:55:36.886
703cd652-ae51-4a47-937f-8370e5a3acf6	tenders	update	tenders:update	Permission to update tenders	2026-07-04 12:06:33.457
a01523af-34a1-4170-afad-0e06421ff223	tenders	delete	tenders:delete	Permission to delete tenders	2026-07-04 12:06:33.458
1e6eb8ef-f183-41c4-8fbb-85c61cce6050	organizations	read	organizations:read	Permission to read organizations	2026-07-04 12:06:33.464
4261a4be-5ab6-47ca-bc7d-a5386e15ba78	projects	update	projects:update	Permission to update projects	2026-07-04 14:22:04.917
d5a92009-ef4e-4075-9609-0e96230885e3	projects	delete	projects:delete	Permission to delete projects	2026-07-04 14:22:04.917
445f99e4-d8b4-4a39-b619-8e7981d4b5fe	finance	create	finance:create	Permission to create finance	2026-07-04 14:49:32.719
a6ef63a6-a1c1-44ac-899f-9748b8ab2f8f	users	create	users:create	Permission to create users	2026-07-04 05:55:36.866
cecfe86a-a917-482b-94b1-81343a8acc1e	users	read	users:read	Permission to read users	2026-07-04 05:55:36.873
9e66766a-e265-4fe3-9908-a61f7fe7d7f1	users	update	users:update	Permission to update users	2026-07-04 05:55:36.874
6ae253f3-0c64-4068-a5e7-2caf5a2b9460	users	delete	users:delete	Permission to delete users	2026-07-04 05:55:36.875
3e005021-6128-4f92-823b-17315336639c	boq	update	boq:update	Permission to update boq	2026-07-04 13:02:31.067
ab6013ab-94d0-499b-9bd0-4de50c1a923e	finance	read	finance:read	Permission to read finance	2026-07-04 14:49:32.72
76f1bc59-238d-42b6-8d71-466eb3dc539b	finance	update	finance:update	Permission to update finance	2026-07-04 14:49:32.72
2e3cb2ff-ea17-4f4d-91ec-e596dc2ff897	finance	delete	finance:delete	Permission to delete finance	2026-07-04 14:49:32.721
\.


--
-- Data for Name: project_bills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_bills (id, "projectId", "billNumber", "billDate", "cumulativeAmount", "currentBillAmount", status, remarks, "createdById", "createdAt", "updatedAt") FROM stdin;
c70c0cad-0bb4-4248-8475-1567fe4e62a1	b5a82a94-6b39-44b9-b870-8e14448e3842	RA-1	2026-07-04 14:26:14.195	100000	100000	DRAFT	\N	9125a4ce-5438-40ef-a999-2cb595ed4156	2026-07-04 14:26:14.195	2026-07-04 14:26:14.195
\.


--
-- Data for Name: project_labor_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_labor_entries (id, "projectId", category, description, "workerCount", units, "ratePerUnit", amount, "entryDate", remarks, "recordedById", "createdAt") FROM stdin;
8e29e7c4-b55f-49a8-b115-12bf34185de0	b5a82a94-6b39-44b9-b870-8e14448e3842	SKILLED	Masons	4	8	50	1600	2026-07-04 14:26:12.995	\N	9125a4ce-5438-40ef-a999-2cb595ed4156	2026-07-04 14:26:12.995
\.


--
-- Data for Name: project_material_usages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_material_usages (id, "projectId", "boqItemId", "materialName", unit, "quantityUsed", "usageDate", remarks, "recordedById", "createdAt") FROM stdin;
\.


--
-- Data for Name: project_milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_milestones (id, "projectId", title, "plannedDate", "completedDate", status, "weightPercent", "sortOrder", "createdAt", "updatedAt") FROM stdin;
289dc043-c019-44fa-a875-29ca4e7059ee	e8dba173-1058-4f05-a05b-03c2f8206665	Foundation Work	\N	2026-07-04 14:25:04.105	COMPLETED	50	0	2026-07-04 14:25:03.1	2026-07-04 14:25:04.105
d27c700c-0320-426c-ac8c-6a3377b07abb	b5a82a94-6b39-44b9-b870-8e14448e3842	Foundation Work	\N	2026-07-04 14:26:11.729	COMPLETED	50	0	2026-07-04 14:26:10.704	2026-07-04 14:26:11.729
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, "tenderId", name, status, budget, "startDate", "endDate", "actualEndDate", location, notes, "createdById", "createdAt", "updatedAt") FROM stdin;
b5b28471-e9b1-416c-a776-a13716dc3bcc	f2e13ccb-39c4-4fdb-b71e-527781f118f8	Phase 5 Highway Project	ACTIVE	480000	2026-07-04 00:00:00	\N	\N	Test City	\N	9125a4ce-5438-40ef-a999-2cb595ed4156	2026-07-04 14:23:52.536	2026-07-04 14:23:52.536
e8dba173-1058-4f05-a05b-03c2f8206665	a29ba86e-27be-4134-a8cb-43edeec828b4	Phase 5 Highway Project	ACTIVE	480000	2026-07-04 00:00:00	\N	\N	Test City	\N	9125a4ce-5438-40ef-a999-2cb595ed4156	2026-07-04 14:25:02.634	2026-07-04 14:25:02.634
b5a82a94-6b39-44b9-b870-8e14448e3842	1a779b72-7d03-4cef-9d38-fb3d189b2d2f	Phase 5 Highway Project	ACTIVE	480000	2026-07-04 00:00:00	\N	\N	Test City	\N	9125a4ce-5438-40ef-a999-2cb595ed4156	2026-07-04 14:26:10.248	2026-07-04 14:26:10.248
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_items (id, "purchaseOrderId", description, unit, quantity, rate, amount, "receivedQuantity", "sortOrder") FROM stdin;
ce6a2544-5a98-4375-8d01-096de8cfaae5	b6828c4c-f8d6-4f34-bdf3-a1222de46533	OPC Cement	bag	500	375	187500	500	0
b4b047c6-6298-4732-b26c-aa9e3b089dba	17974ee2-ff59-40f1-90fa-022a968c79d4	OPC Cement	bag	500	375	187500	500	0
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, "poNumber", "vendorId", "tenderId", "sourceRfqId", status, "expectedDeliveryDate", notes, "createdById", "createdAt", "updatedAt") FROM stdin;
b6828c4c-f8d6-4f34-bdf3-a1222de46533	PO-7BD4DCA2	f9551d89-b587-43a1-867c-040650349875	\N	d437c0fc-4878-4909-a379-f40897d2b686	RECEIVED	\N	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:01:06.476	2026-07-04 14:01:10.044
17974ee2-ff59-40f1-90fa-022a968c79d4	PO-4FAE96C2	d0df4401-c24f-4d84-bce6-01686a8fadac	\N	fc9b863f-70c9-4aa8-b835-69a6dfff8630	RECEIVED	\N	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:02:17.116	2026-07-04 14:02:19.465
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, "userId", "tokenHash", family, "deviceInfo", "ipAddress", "isRevoked", "replacedByTokenHash", "expiresAt", "createdAt") FROM stdin;
186086d4-e399-4542-8ec8-37297727c9f6	4657478c-787b-4192-bf46-7a954fc9bc17	917adef37ecdb1a546966d65a3274c1b2be18535d8b3490949c57a38dd5d61c0	b16424c3-0ce7-4a79-b1d6-65dc7db5a7dc	curl/8.7.1	::1	f	\N	2026-08-03 05:58:00.501	2026-07-04 05:58:00.502
65f0eff3-25b0-4295-8dc5-ad7fc43da245	4657478c-787b-4192-bf46-7a954fc9bc17	d13ab295ebc034494905f4f88c8ffb4255ad012222e9ff970872992ef0d37721	c3e1f82c-6b5b-4d09-b7d1-74af8b1eb6a9	curl/8.7.1	::1	t	2fc3d39d3a34372d121cd7d7dbe15e8492586a739e87ee4150854ba13ab9666e	2026-08-03 05:58:10.753	2026-07-04 05:58:10.754
4cd8ba67-78a4-4479-a627-771e9a12ac5c	4657478c-787b-4192-bf46-7a954fc9bc17	2fc3d39d3a34372d121cd7d7dbe15e8492586a739e87ee4150854ba13ab9666e	c3e1f82c-6b5b-4d09-b7d1-74af8b1eb6a9	curl/8.7.1	::1	f	\N	2026-08-03 05:58:10.949	2026-07-04 05:58:10.949
c82248b7-d2fc-47ad-b9a4-d03ad3d3f0ad	d07c5c47-66e7-4331-85cd-a0aeb5171e1b	351f7f9d59eabf804d593a3c5e5322b11e35af998cb125b801ec1d614a1f98cc	ed524e4e-b0c8-46c8-8bdb-5096d570ef11	curl/8.7.1	::1	f	\N	2026-08-03 05:58:24.877	2026-07-04 05:58:24.877
25846b96-7777-4c1a-8d4f-b2418150a814	4657478c-787b-4192-bf46-7a954fc9bc17	1d593d592c7897a8e8be0437d801a26aff5c559ed259dd864a8d62b4a2445995	9beb8f0a-2b24-405e-a9f2-3cca954697dc	curl/8.7.1	::1	f	\N	2026-08-03 05:58:41.556	2026-07-04 05:58:41.558
786e36ce-37cb-43e0-93bd-1dafc03ea5da	4657478c-787b-4192-bf46-7a954fc9bc17	6ebb5d8835eaec0f2dd4ddbdaffbbf0c943c9ff583db02756490f36ec033cc5a	b01eaa78-3db7-4910-a0ad-7f570f5bda9a	curl/8.7.1	::1	f	\N	2026-08-03 05:58:52.958	2026-07-04 05:58:52.96
3a15bc23-7503-4a81-990f-0a35b9a38908	4657478c-787b-4192-bf46-7a954fc9bc17	5f61bc3eb24dc838360ca688654caf950e29b5376de1abec9f05ef2eac6102c6	2e7575ed-4ab2-4b26-b695-b04ced5ad541	curl/8.7.1	::1	f	\N	2026-08-03 05:59:02.795	2026-07-04 05:59:02.795
074c3db9-0099-4bf4-b771-33d84043a787	4657478c-787b-4192-bf46-7a954fc9bc17	0462203af3d7ba9883435f731357c84f2e757df16050f6189174ed213e2fb58f	48693625-bec7-4967-b977-59fcf3eb3323	curl/8.7.1	::1	f	\N	2026-08-03 05:59:17.492	2026-07-04 05:59:17.493
db5cc890-768d-4f93-af53-e1e3f7111753	4657478c-787b-4192-bf46-7a954fc9bc17	9e4c9bfe0f6650d37e4198887010c67331eb192584678a88ffe8e729485091df	2e2dbaef-8595-449e-bced-46f07a1e58d6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	e5ce0e7997e2ebc67051a00d954d274d900ac3ac26df73bbb55dd857b1bf8d10	2026-08-03 06:02:06.14	2026-07-04 06:02:06.141
d6956ec6-22b4-4f19-b83e-ec3e399daaf4	4657478c-787b-4192-bf46-7a954fc9bc17	e5ce0e7997e2ebc67051a00d954d274d900ac3ac26df73bbb55dd857b1bf8d10	2e2dbaef-8595-449e-bced-46f07a1e58d6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	74418946f955c265a3d0b4474c8ce279f61b7fe9c75ed24f5e2779b94413676e	2026-08-03 06:02:08.516	2026-07-04 06:02:08.517
f387f540-6806-4a51-87ea-954b7318639f	4657478c-787b-4192-bf46-7a954fc9bc17	74418946f955c265a3d0b4474c8ce279f61b7fe9c75ed24f5e2779b94413676e	2e2dbaef-8595-449e-bced-46f07a1e58d6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	ec11e0d41db877cc67a44c4bc11b0dbc52d548c933879948b8f19d287e8f8e61	2026-08-03 06:02:10.654	2026-07-04 06:02:10.655
7a787468-9f03-4226-927d-57d7167ad4b6	4657478c-787b-4192-bf46-7a954fc9bc17	ec11e0d41db877cc67a44c4bc11b0dbc52d548c933879948b8f19d287e8f8e61	2e2dbaef-8595-449e-bced-46f07a1e58d6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	3b304fc35e4aef28a2788c492169201bb791c4f0f62cbb4d9191260793221cc6	2026-08-03 06:02:12.268	2026-07-04 06:02:12.268
3b5b4f7e-8d06-4c3c-ae42-00c098f1542f	4657478c-787b-4192-bf46-7a954fc9bc17	3b304fc35e4aef28a2788c492169201bb791c4f0f62cbb4d9191260793221cc6	2e2dbaef-8595-449e-bced-46f07a1e58d6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 06:02:13.353	2026-07-04 06:02:13.354
a8b46de8-1d74-4544-96a6-917785c307ab	4657478c-787b-4192-bf46-7a954fc9bc17	3720aa5d470a41425005fcd511e9e5f665f677f7d0c5a8319c7643b211b0b997	be5dd800-9385-4849-a773-ec4824563794	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	486ac71afdcb7c621944b8ae8e182d225bd1f0b110c1004e1ba27b9abe51439b	2026-08-03 06:03:15.936	2026-07-04 06:03:15.937
20a3841e-8741-409f-bd7b-b046132022a3	4657478c-787b-4192-bf46-7a954fc9bc17	486ac71afdcb7c621944b8ae8e182d225bd1f0b110c1004e1ba27b9abe51439b	be5dd800-9385-4849-a773-ec4824563794	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	ed7d3d75af92f50a87d98751dcbc62ec3093369397cb621e3c831d26f7682dea	2026-08-03 06:03:17.551	2026-07-04 06:03:17.552
3d765928-57ea-4ff2-9625-7d3b54aeab3e	4657478c-787b-4192-bf46-7a954fc9bc17	ed7d3d75af92f50a87d98751dcbc62ec3093369397cb621e3c831d26f7682dea	be5dd800-9385-4849-a773-ec4824563794	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	87fe2a5e16ddc6155d47d19483e77fd936ad7fe696bb9f9b6c705a862d3299de	2026-08-03 06:03:18.809	2026-07-04 06:03:18.81
0a070d04-188e-458b-82d5-509ea2ff240d	4657478c-787b-4192-bf46-7a954fc9bc17	87fe2a5e16ddc6155d47d19483e77fd936ad7fe696bb9f9b6c705a862d3299de	be5dd800-9385-4849-a773-ec4824563794	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	c2858ba955e6e1d80f396b4587276826d86bbee59affe7835bd672da7b3b5e6c	2026-08-03 06:03:19.862	2026-07-04 06:03:19.862
d1b042d5-4f5b-4a7b-8092-21858fa20284	4657478c-787b-4192-bf46-7a954fc9bc17	c2858ba955e6e1d80f396b4587276826d86bbee59affe7835bd672da7b3b5e6c	be5dd800-9385-4849-a773-ec4824563794	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	\N	2026-08-03 06:03:20.889	2026-07-04 06:03:20.89
7ba68d0d-8c9a-4956-88db-ceccb2edd8d9	4657478c-787b-4192-bf46-7a954fc9bc17	036371b279f44e4b7639a5bb17fe9121be002af5429f59209a7d398f83b988e0	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	4533f456f90af715caf315f3aff7d69520a89457dde235a9fe4b1f72967736a7	2026-08-03 06:06:45.851	2026-07-04 06:06:45.852
03aba153-f719-435e-a53d-713963ed9348	80831d57-c57c-4d5e-bb18-f22e8a782664	cdf4a257c1a3550053cd940ab70d36e126088b689e33793db411e6969927fc6c	c2835f8a-6458-48be-9e92-bd0194eea3c4	curl/8.7.1	::1	f	\N	2026-08-03 12:08:17.325	2026-07-04 12:08:17.327
ab5b94b6-d5e4-419e-8e2a-e5f3bc2e3342	80831d57-c57c-4d5e-bb18-f22e8a782664	2bc6a31b8eec089871392a662d29f03c4e035793225adab374e7a13b08cb07fc	ff1fcc12-64d9-4933-b1b9-0de52c21f5d9	curl/8.7.1	::1	f	\N	2026-08-03 12:08:43.101	2026-07-04 12:08:43.101
92c63451-1ba5-4be5-b679-d6c6dcc3eb80	80831d57-c57c-4d5e-bb18-f22e8a782664	aaccfcc0ae7f908af8701e7e9696a5753ae705a6c0397e35a91eb6ea77516b6a	a9df988d-d340-4326-aa2a-00edd74df397	curl/8.7.1	::1	f	\N	2026-08-03 12:09:06.049	2026-07-04 12:09:06.049
c66909ec-2e72-4db1-be3b-4f757a0c8287	4657478c-787b-4192-bf46-7a954fc9bc17	4533f456f90af715caf315f3aff7d69520a89457dde235a9fe4b1f72967736a7	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	e694abd90d193f7278fdd0da215437e1b41b948c3773413a00e40ccda2096054	2026-08-03 06:28:21.838	2026-07-04 06:28:21.839
20aedc9b-09a5-4db2-8b2a-99cc60224898	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	8bd0aa3cec64079b48687f4dbaf8f1c67d0a6d1d29b372d081e9de39193e3dd5	c43eb6fc-c901-465a-82ec-9d0e99855077	curl/8.7.1	::1	f	\N	2026-08-03 12:11:53.132	2026-07-04 12:11:53.134
0f0f5699-2ee6-4147-baf3-bb1ff40ffa8f	80831d57-c57c-4d5e-bb18-f22e8a782664	6676693f3df9d536338279e6b0a8268558c61d7eae503f428c5541ac9e20fb19	4cc71dec-4043-411f-beb0-1a8119799a41	curl/8.7.1	::1	f	\N	2026-08-03 12:11:53.426	2026-07-04 12:11:53.427
f18e2fe1-b0bf-4f04-8ba1-53197f953008	80831d57-c57c-4d5e-bb18-f22e8a782664	48ad580b51618a1aeafc461729839bd793ad0c63bd7d1eeae56b378c2dcd4e38	2ddb27aa-9540-44b0-85b6-516ccff020a0	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	17ab7ec0419701e3f9018ef42d02f59dba39e76df8ee5037b31a65a03a960eff	2026-08-03 12:12:43.005	2026-07-04 12:12:43.006
ff588084-bf59-4496-a434-4df3942b9aea	80831d57-c57c-4d5e-bb18-f22e8a782664	17ab7ec0419701e3f9018ef42d02f59dba39e76df8ee5037b31a65a03a960eff	2ddb27aa-9540-44b0-85b6-516ccff020a0	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	db46ac5611867d75df82865bcca02a096225a424b78bcb4762737d7f552be935	2026-08-03 12:12:48.733	2026-07-04 12:12:48.733
91a4d4d7-1bf7-4229-8ad5-7ed1927a8f87	80831d57-c57c-4d5e-bb18-f22e8a782664	db46ac5611867d75df82865bcca02a096225a424b78bcb4762737d7f552be935	2ddb27aa-9540-44b0-85b6-516ccff020a0	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	d512f716ec1e26cd4bea4b7edcb3ba6ca49fa06180e1463f84be27f8a5092893	2026-08-03 12:12:54.446	2026-07-04 12:12:54.447
d6a1089a-3f9f-4f27-b052-741657c29821	80831d57-c57c-4d5e-bb18-f22e8a782664	d512f716ec1e26cd4bea4b7edcb3ba6ca49fa06180e1463f84be27f8a5092893	2ddb27aa-9540-44b0-85b6-516ccff020a0	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 12:12:55.745	2026-07-04 12:12:55.746
b04331c7-c5d0-4a96-aafc-29d7a1fa956e	d07c5c47-66e7-4331-85cd-a0aeb5171e1b	d17c8d81b585e14f453494513d9ef8683ee3c6d306faf38d773b79633ebe9052	c6ceca44-945b-4eaf-9c17-d6ccd1a4a1ce	curl/8.7.1	::1	f	\N	2026-08-03 12:14:53.443	2026-07-04 12:14:53.444
317c379a-1fea-4ec6-8ef7-80aa866b8988	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	8b6ddd93326ac0b7d1e2e30ecc43ec58958877fbf556cb8e1e33f8942a0b68e9	8fb6d704-1296-4db6-9998-f0a72fb982c8	curl/8.7.1	::1	f	\N	2026-08-03 12:14:53.787	2026-07-04 12:14:53.788
277e32f5-ce32-4e9f-9679-8a911cd90e3c	4657478c-787b-4192-bf46-7a954fc9bc17	e694abd90d193f7278fdd0da215437e1b41b948c3773413a00e40ccda2096054	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	4a0723fbcbf6ea35fa1c8d8ac5ece559dedab1a403b04a0b9bdf4916614607bc	2026-08-03 12:17:30.899	2026-07-04 12:17:30.9
bb2a1bf3-d40c-4763-9c9a-64aee7aa538f	4657478c-787b-4192-bf46-7a954fc9bc17	4a0723fbcbf6ea35fa1c8d8ac5ece559dedab1a403b04a0b9bdf4916614607bc	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	a03e1103cc09f8bf742e93c606a4d76f8f9bfd34ba273bd023bf77a20bed100e	2026-08-03 12:32:32.398	2026-07-04 12:32:32.399
03f639a9-9e0e-484f-a885-4adf12a08532	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	41b558a7236918a0c8d435e7b4c83e72b394bbc2ac5f006c9e06d18cf3158d03	5853441f-eb69-413c-8dad-ae5ee6681bf3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	307ae371ed414e5d87a367e5bc5f50e24afb0de06ef27129c56506f4e377e9dd	2026-08-03 13:08:03.422	2026-07-04 13:08:03.423
ea3d1206-83a9-4015-a119-8b6fb291a035	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	307ae371ed414e5d87a367e5bc5f50e24afb0de06ef27129c56506f4e377e9dd	5853441f-eb69-413c-8dad-ae5ee6681bf3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 13:08:09.805	2026-07-04 13:08:09.809
9a9a12f2-c7ac-4326-a554-082ac30929b0	4657478c-787b-4192-bf46-7a954fc9bc17	a03e1103cc09f8bf742e93c606a4d76f8f9bfd34ba273bd023bf77a20bed100e	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	18b157560a419f41a35ff44d4f63f4636617e624f7fae0d2d4d15c1ae786c72b	2026-08-03 12:48:20.197	2026-07-04 12:48:20.198
c9dd50be-dd81-412d-b519-965507cbbae7	4657478c-787b-4192-bf46-7a954fc9bc17	18b157560a419f41a35ff44d4f63f4636617e624f7fae0d2d4d15c1ae786c72b	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	a55266cc6a7557257ea4ee41fe3533e90447443fac426d9e88b52fee7ee363fa	2026-08-03 13:08:10.695	2026-07-04 13:08:10.697
7c5e1e6d-1dce-4ad2-ba18-a50619203f83	4657478c-787b-4192-bf46-7a954fc9bc17	a55266cc6a7557257ea4ee41fe3533e90447443fac426d9e88b52fee7ee363fa	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	30d6f49fd3388dd8791cf11e7465e12f6da717665bc1d8cd124f70b120330177	2026-08-03 13:12:17.203	2026-07-04 13:12:17.204
7634e5f4-32cf-477d-9af1-a5237fe8c26d	4657478c-787b-4192-bf46-7a954fc9bc17	30d6f49fd3388dd8791cf11e7465e12f6da717665bc1d8cd124f70b120330177	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	4c869bc8ce9eaa0f87421ee2c3ef0f7fc0cfecfc4db5d67b5f4d990922027126	2026-08-03 13:27:19.103	2026-07-04 13:27:19.104
eb0dad01-22de-41f5-beec-9fd0a337beff	4657478c-787b-4192-bf46-7a954fc9bc17	4c869bc8ce9eaa0f87421ee2c3ef0f7fc0cfecfc4db5d67b5f4d990922027126	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	ee1ed9f165341730f1a7d187e7ac0395ad858c3f55051ccc1cc88cde0b3bbc19	2026-08-03 13:37:08.732	2026-07-04 13:37:08.733
23a3953f-c4e8-4338-995b-ec2d4b86c39b	4657478c-787b-4192-bf46-7a954fc9bc17	ee1ed9f165341730f1a7d187e7ac0395ad858c3f55051ccc1cc88cde0b3bbc19	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	de4296df99c96ff399f103d0275c4f13117455ae532edb1327774c071a0b75c3	2026-08-03 13:42:23.043	2026-07-04 13:42:23.043
ac86ccda-b7b4-4d3d-bb0e-8681512dd5f3	4657478c-787b-4192-bf46-7a954fc9bc17	de4296df99c96ff399f103d0275c4f13117455ae532edb1327774c071a0b75c3	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	27e0670a02a68d43798f4f0be5c07ebf0fe45e465679496e376c8b3ea8d844d8	2026-08-03 13:44:51.68	2026-07-04 13:44:51.681
6984f3ef-c872-49a8-b7dd-e51cc8f0a516	4657478c-787b-4192-bf46-7a954fc9bc17	27e0670a02a68d43798f4f0be5c07ebf0fe45e465679496e376c8b3ea8d844d8	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	67808256bc83135b2774b899fe565b8355ba694c04ee9ecd543b415c3f4c2ecb	2026-08-03 13:45:46.449	2026-07-04 13:45:46.45
53c04ea8-c147-48a9-af01-526c14741e28	4657478c-787b-4192-bf46-7a954fc9bc17	67808256bc83135b2774b899fe565b8355ba694c04ee9ecd543b415c3f4c2ecb	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	ad891eaec90cae6f6fbaf463e89ad42be2ea446c00577a97099461e3c8ff394d	2026-08-03 13:46:12.437	2026-07-04 13:46:12.437
ffd136bd-8c91-418c-b768-e22fa31de498	4657478c-787b-4192-bf46-7a954fc9bc17	ad891eaec90cae6f6fbaf463e89ad42be2ea446c00577a97099461e3c8ff394d	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	b69d8faef37f488ffe4b243fa6e4f39bc8276a56c4ef250c1333d2ba45fb18f0	2026-08-03 13:46:37.242	2026-07-04 13:46:37.243
35252da0-03a9-483e-b251-3bb662bee638	4657478c-787b-4192-bf46-7a954fc9bc17	b69d8faef37f488ffe4b243fa6e4f39bc8276a56c4ef250c1333d2ba45fb18f0	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	17859134d18b0fb6922a7cb2e6d1ed59e930c05ad3ff70e9b4bcb48f61bef09f	2026-08-03 13:46:53.335	2026-07-04 13:46:53.336
c3e438be-1fe5-4b93-886c-22a60070916f	4657478c-787b-4192-bf46-7a954fc9bc17	17859134d18b0fb6922a7cb2e6d1ed59e930c05ad3ff70e9b4bcb48f61bef09f	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	33a574209a8fa6c989f45d17c957e4ba7e70e4c2596c89fed45b464109198c82	2026-08-03 13:47:02.91	2026-07-04 13:47:02.911
7798656f-9813-4a44-a8b6-4fdb33c0f4e6	4657478c-787b-4192-bf46-7a954fc9bc17	33a574209a8fa6c989f45d17c957e4ba7e70e4c2596c89fed45b464109198c82	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	0ec91a76ea0351b634f4eca2f9677587c5eb3f2b4ac4c8c9fa24dbc2c0a15472	2026-08-03 13:47:09.641	2026-07-04 13:47:09.642
5f8f9c61-89e9-4c37-9023-06bfbf8c6b8b	4657478c-787b-4192-bf46-7a954fc9bc17	0ec91a76ea0351b634f4eca2f9677587c5eb3f2b4ac4c8c9fa24dbc2c0a15472	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	6e7c9fd79bd266863c95e2240178a8e0bb10f00f5419f526001d7137148e8469	2026-08-03 13:47:10.672	2026-07-04 13:47:10.673
911038b9-afa4-44c6-9d4b-02308010ba2f	4657478c-787b-4192-bf46-7a954fc9bc17	6e7c9fd79bd266863c95e2240178a8e0bb10f00f5419f526001d7137148e8469	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	28a208531c90bee70ddf5ec44e07f5f73e97f0df39659e8c870642e1e9b58e26	2026-08-03 13:47:17.597	2026-07-04 13:47:17.598
ba005fed-b639-4ee4-99be-e70c7b830143	4657478c-787b-4192-bf46-7a954fc9bc17	28a208531c90bee70ddf5ec44e07f5f73e97f0df39659e8c870642e1e9b58e26	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	068e7ac731d8e55f914b46f516ad766a3ecffffabb62fac11ecf86f443a572e5	2026-08-03 13:47:59.963	2026-07-04 13:47:59.964
4023f38e-048d-4cce-8802-83d30b6d6d1a	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	f527a7d4cfa9729e2b75e01caba1d54754bd66f1038df97301d9c00436b6e5b6	1716b917-550b-450d-a6ee-85ebc1f9fcc6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	49bc76fcff72a8b1a95a506f9ee088acd14f5e02fbd31b496b1c09c3eb908cf3	2026-08-03 13:53:02.95	2026-07-04 13:53:02.95
c8e0bc2b-2854-4f28-be70-6d1900f895eb	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	49bc76fcff72a8b1a95a506f9ee088acd14f5e02fbd31b496b1c09c3eb908cf3	1716b917-550b-450d-a6ee-85ebc1f9fcc6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 13:53:07.395	2026-07-04 13:53:07.396
d6cf05b1-bc06-4dff-9008-e080d53ff874	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	1c6fc480e153ed3d3d709974584cb099d834846a60376b526bdb5fdc62644bd6	53990aa8-7f06-4422-9e7d-6b6d607f45e3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	266f7ae3a50a0a296364db2d52ba9a74e166f4ac188ee89ddf980e5de7837c5f	2026-08-03 13:53:54.81	2026-07-04 13:53:54.81
2e3fcc72-45f5-44ef-89d0-3d794bbf4da0	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	266f7ae3a50a0a296364db2d52ba9a74e166f4ac188ee89ddf980e5de7837c5f	53990aa8-7f06-4422-9e7d-6b6d607f45e3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	d5e08a588759fb6988bae93b1d35608b5fe588fdc505a0bc0870d924af217df0	2026-08-03 13:53:55.75	2026-07-04 13:53:55.751
86d2da76-2f19-4a88-8089-092a513f8850	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	d5e08a588759fb6988bae93b1d35608b5fe588fdc505a0bc0870d924af217df0	53990aa8-7f06-4422-9e7d-6b6d607f45e3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	c6b9f8621035b1f5da114b281af3fb3e9f3e5b78b41f22db0c795de327992acc	2026-08-03 13:53:58.514	2026-07-04 13:53:58.515
a16bbb40-e5f9-47d2-b5f8-065aa4eb2f0a	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	c6b9f8621035b1f5da114b281af3fb3e9f3e5b78b41f22db0c795de327992acc	53990aa8-7f06-4422-9e7d-6b6d607f45e3	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 13:54:01.105	2026-07-04 13:54:01.106
9f945894-2cf2-4c31-8e7b-91e67f8d6243	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	4560c1fa07f2939f0a964dc98203102dba8cb36d6efce71f67e6cc179ee01995	f481c6c3-56dc-479f-bfdf-21171c0fbb82	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	660e2b680eebf02fd6a7589b48893daf24f039f97f2492919823335bb5551a2f	2026-08-03 13:55:41.449	2026-07-04 13:55:41.45
9e2596da-139e-40e0-96b0-d79a08b78a5c	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	660e2b680eebf02fd6a7589b48893daf24f039f97f2492919823335bb5551a2f	f481c6c3-56dc-479f-bfdf-21171c0fbb82	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	6796efaf1aa56d3d354ff5ce6a607e6290cfe48f577add017b50d69443be061d	2026-08-03 13:55:42.329	2026-07-04 13:55:42.33
9db3ec13-eb8d-42d0-aea8-c158b9f3e657	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	6796efaf1aa56d3d354ff5ce6a607e6290cfe48f577add017b50d69443be061d	f481c6c3-56dc-479f-bfdf-21171c0fbb82	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	4176932105b1f5f45d426b7e8aba971953f2b43a22c8cd2a38c1764b7bf0ee88	2026-08-03 13:55:43.76	2026-07-04 13:55:43.761
0da41d13-fe23-4d6a-833c-f34ceb2ad7ed	4657478c-787b-4192-bf46-7a954fc9bc17	068e7ac731d8e55f914b46f516ad766a3ecffffabb62fac11ecf86f443a572e5	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	t	1c8d4db81c20eeeccd3c11ae366223af9f17a94d2e86f0c8a3fbbdb5d3041bae	2026-08-03 13:49:45.467	2026-07-04 13:49:45.468
93ab8b63-309d-466a-a7c9-20aaeacc24ad	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	4176932105b1f5f45d426b7e8aba971953f2b43a22c8cd2a38c1764b7bf0ee88	f481c6c3-56dc-479f-bfdf-21171c0fbb82	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 13:55:44.834	2026-07-04 13:55:44.834
24a34e2d-c096-4d8a-863a-b7cfeca2a105	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	e9c59a1005a9a084d88092d46dc5f3b2b2d0ae9d2125b8956cced71a533dbaa6	f5ba5991-f9fa-4bc3-8736-e7b31ffccee4	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	db64e8a0aa8056d56ab1d0edd19cca5cce421f3149bdf2d48ad16fb56c67ad3a	2026-08-03 13:57:17.603	2026-07-04 13:57:17.604
b3dec878-005d-4b33-8aad-b82e2797d21b	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	db64e8a0aa8056d56ab1d0edd19cca5cce421f3149bdf2d48ad16fb56c67ad3a	f5ba5991-f9fa-4bc3-8736-e7b31ffccee4	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	573399f1fbf5e96252858985c9b460b8d46e54e93176c3a1ef0224506d6e4afb	2026-08-03 13:57:18.492	2026-07-04 13:57:18.493
db0bbc90-c43e-4e6c-9552-e04098ff84ec	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	573399f1fbf5e96252858985c9b460b8d46e54e93176c3a1ef0224506d6e4afb	f5ba5991-f9fa-4bc3-8736-e7b31ffccee4	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	49c02c900a57e5d5c9ad29d19e8071ead713bb91e32434f573c8e1cfd01bd330	2026-08-03 13:57:20.127	2026-07-04 13:57:20.127
5e377bef-a208-4246-85e0-886423a5061d	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	49c02c900a57e5d5c9ad29d19e8071ead713bb91e32434f573c8e1cfd01bd330	f5ba5991-f9fa-4bc3-8736-e7b31ffccee4	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 13:57:21.297	2026-07-04 13:57:21.298
cc162cf0-ebfb-4682-aa32-a33656f32859	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	974ef073a521ebd76e9810f5d58e5b46a831321f4bf77368a6b86d013af1d9cb	c021a39f-3a48-4011-9d50-28bc3b392e13	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	af4b427f05127718ec95845120dd7f0e128c1fa6cd81d12004a68652409f7187	2026-08-03 13:58:19.274	2026-07-04 13:58:19.274
83fa9c31-012c-487a-b31d-0115e0734f5d	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	af4b427f05127718ec95845120dd7f0e128c1fa6cd81d12004a68652409f7187	c021a39f-3a48-4011-9d50-28bc3b392e13	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	8ac4f835299f5874d1295a42e2f513da44fa28a4fbc51f8b747c0f04c7625660	2026-08-03 13:58:20.02	2026-07-04 13:58:20.021
bb89c30e-2e10-4753-a80d-b831d92a1c23	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	8ac4f835299f5874d1295a42e2f513da44fa28a4fbc51f8b747c0f04c7625660	c021a39f-3a48-4011-9d50-28bc3b392e13	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	689c105b7cfd31ad79bbb3ffe510368c37ef6b4245e1e0cf0b37d5b4e10f875b	2026-08-03 13:58:21.384	2026-07-04 13:58:21.385
9c3c2264-483f-4467-8d7a-c68a44fe556b	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	689c105b7cfd31ad79bbb3ffe510368c37ef6b4245e1e0cf0b37d5b4e10f875b	c021a39f-3a48-4011-9d50-28bc3b392e13	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 13:58:22.419	2026-07-04 13:58:22.42
7404ac72-961f-49a5-8160-2e2b9f8c0a2f	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	399c2c2cb39051d7f917fb99964be25ad24e94ec28e4902b3d2aba577f9ba3db	db7c1efd-8a07-4b6e-bfff-8a450facc623	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	ae14e1e988f7050e6ea864a41cfbd01b775223aae6ba65819bdc6f1f26685865	2026-08-03 14:00:53.177	2026-07-04 14:00:53.178
c75fd2a9-4530-4293-9a28-9b5efc491c0f	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	ae14e1e988f7050e6ea864a41cfbd01b775223aae6ba65819bdc6f1f26685865	db7c1efd-8a07-4b6e-bfff-8a450facc623	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	1f14fbe462739e9bfe3c158f10c25bd7a8b22c4d2b7bb839dabf09910d1cdf88	2026-08-03 14:00:56.342	2026-07-04 14:00:56.343
c5aa998b-f80f-49e0-873e-d87339caf2a3	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	1f14fbe462739e9bfe3c158f10c25bd7a8b22c4d2b7bb839dabf09910d1cdf88	db7c1efd-8a07-4b6e-bfff-8a450facc623	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	c2ec3c924654aaf93c81365302ff6315c44f33fe6cca8ce01646d4cfdffb3c95	2026-08-03 14:00:59.092	2026-07-04 14:00:59.093
69604cd3-d098-41c9-bc6f-703bc6a8674b	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	c2ec3c924654aaf93c81365302ff6315c44f33fe6cca8ce01646d4cfdffb3c95	db7c1efd-8a07-4b6e-bfff-8a450facc623	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	7a15b830259ce6085fd35ff58fe1c0a93c584737848230a33a4db9a4a5cd88dc	2026-08-03 14:01:01.157	2026-07-04 14:01:01.158
49b2d6fd-acd6-49e7-a98c-ba34bca457c0	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	7a15b830259ce6085fd35ff58fe1c0a93c584737848230a33a4db9a4a5cd88dc	db7c1efd-8a07-4b6e-bfff-8a450facc623	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 14:01:12.327	2026-07-04 14:01:12.328
edb80611-2ad9-4792-9afb-cb791b692f39	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	7ec5f121449edbdf171628ca25b1bc3dafcf4869f7be901903b1faf2ff76457a	87acccc1-952f-4724-990b-5de309fec8cf	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	b5727cee960c2e49b0ba829ce4c2c7d9ca363cef73971390bc29905d06dac762	2026-08-03 14:02:10.002	2026-07-04 14:02:10.003
726a3208-e6e2-4087-b4a8-1b099650c492	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	b5727cee960c2e49b0ba829ce4c2c7d9ca363cef73971390bc29905d06dac762	87acccc1-952f-4724-990b-5de309fec8cf	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	d068a1e9236ffdfc134289003e8a9d08d5fa0f3f97ebb8c0106dabe7fb510a2a	2026-08-03 14:02:10.786	2026-07-04 14:02:10.787
d70de4b6-e218-4458-b902-e2d5a8b431d8	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	d068a1e9236ffdfc134289003e8a9d08d5fa0f3f97ebb8c0106dabe7fb510a2a	87acccc1-952f-4724-990b-5de309fec8cf	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	7b29f05a9d59acc51d659c632ca63918c9e96350f8b3c55b538947eaacc63f96	2026-08-03 14:02:12.073	2026-07-04 14:02:12.074
ead3757c-60d9-4f54-8ebe-64d3bf6150aa	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	7b29f05a9d59acc51d659c632ca63918c9e96350f8b3c55b538947eaacc63f96	87acccc1-952f-4724-990b-5de309fec8cf	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	8fb21fcf5d455846358e87e78f0514e0d221e821e6881be3e7a7ccfff5cad712	2026-08-03 14:02:13.08	2026-07-04 14:02:13.081
fb9b9508-dc62-480d-bdf0-bb87dc011593	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	8fb21fcf5d455846358e87e78f0514e0d221e821e6881be3e7a7ccfff5cad712	87acccc1-952f-4724-990b-5de309fec8cf	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 14:02:21.724	2026-07-04 14:02:21.724
5b8d39db-ae85-4722-bbc8-3d8d0865763c	80831d57-c57c-4d5e-bb18-f22e8a782664	8cc62c82dd0b8aba95bd749f5f920aef19b9aaae0e03538d37137cff394757f5	9592975b-9df5-4fb9-8fd2-f75e62af311e	node	::1	f	\N	2026-08-03 14:23:45.096	2026-07-04 14:23:45.098
e1cd2a50-9c1a-4ea2-97ac-272e44b555ab	9125a4ce-5438-40ef-a999-2cb595ed4156	b791cfb04f14aee73d94c06bd194cec3ef1ad158ad3fa9caa335b537dcafb926	8348d954-3c9b-45ec-8312-da2fae30028c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	d3e8dccbbb55aa6c941a7da0262a631c91c967835895cace7d7b10c5e7c9d30e	2026-08-03 14:23:47.415	2026-07-04 14:23:47.416
aad5e8ee-fc11-46c5-9455-e52397a5d749	9125a4ce-5438-40ef-a999-2cb595ed4156	d3e8dccbbb55aa6c941a7da0262a631c91c967835895cace7d7b10c5e7c9d30e	8348d954-3c9b-45ec-8312-da2fae30028c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 14:23:51.604	2026-07-04 14:23:51.604
68b85647-b7ba-40dc-a1c6-71468d8834b7	80831d57-c57c-4d5e-bb18-f22e8a782664	feaf73523cdbb1ea3b240d8a8b75ae42831b5b7e26b050a28fb229d881a5b60a	8d9bcdbf-40cf-4d76-88ad-bdb9a51c5bbe	node	::1	f	\N	2026-08-03 14:24:58.638	2026-07-04 14:24:58.639
651a63cf-0b36-4a08-8015-f5f877cae47e	9125a4ce-5438-40ef-a999-2cb595ed4156	c3844d6924da16c034e9efbf2f8db22aa7ee5d1176443835c967fabbbdb087ae	71514ca3-11ec-4be4-b32d-571ecfb8e268	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	b5ff94eb4a42084fb762f2c9b53fa6db36469085a882a3121749448a19d821f2	2026-08-03 14:25:00.894	2026-07-04 14:25:00.894
3d0f0033-174d-4cc7-814e-4f8da19880d7	9125a4ce-5438-40ef-a999-2cb595ed4156	b5ff94eb4a42084fb762f2c9b53fa6db36469085a882a3121749448a19d821f2	71514ca3-11ec-4be4-b32d-571ecfb8e268	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 14:25:01.724	2026-07-04 14:25:01.725
439c551b-df55-4fcf-bf8a-4b4ece4f3c92	80831d57-c57c-4d5e-bb18-f22e8a782664	82690eb5c1b69b474fb6899dede0fe005a557ca9b37a4862e75db60202c5af8e	c38f2360-7a18-4012-a121-da154b4307a3	node	::1	f	\N	2026-08-03 14:26:06.451	2026-07-04 14:26:06.452
24248924-0506-431f-b847-230887db3744	9125a4ce-5438-40ef-a999-2cb595ed4156	70b2dd62b84d1705cb140dc9186f68c0f23c1d1af618582ade492155ce98f039	fc7c1e5f-d53b-4f2d-b209-f9a416b07d4b	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	8edb4f3759cd1568b1bad0a5dec2a4659eecd74ea1d704f08068c2356e132ffd	2026-08-03 14:26:08.559	2026-07-04 14:26:08.56
236e515d-2435-4b8d-b63c-48331f6bfe02	9125a4ce-5438-40ef-a999-2cb595ed4156	8edb4f3759cd1568b1bad0a5dec2a4659eecd74ea1d704f08068c2356e132ffd	fc7c1e5f-d53b-4f2d-b209-f9a416b07d4b	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 14:26:09.344	2026-07-04 14:26:09.344
b3a1aceb-e89d-403b-8e40-912115dc1001	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	8a0ba5b3106958f9db035d9090fc72c42b90b98eaa9e94b72ec6549c272ba14b	d077743b-23cc-4289-8c75-5c5480d723f5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	575b62f8e4feef77da064de003c01f7e3ccd02d9237c55d7fa095be70ac3373b	2026-08-03 14:51:03.131	2026-07-04 14:51:03.132
79a84e6b-e5bb-46e9-bf73-1e11a0ab3e55	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	575b62f8e4feef77da064de003c01f7e3ccd02d9237c55d7fa095be70ac3373b	d077743b-23cc-4289-8c75-5c5480d723f5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	4311d43bd6ad27fb63437f0470136e2b1a0fae11bdc3c539fbc74d7115f19dd5	2026-08-03 14:51:06.582	2026-07-04 14:51:06.582
628c0a70-44de-4223-a825-e6a6f5a041d8	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	4311d43bd6ad27fb63437f0470136e2b1a0fae11bdc3c539fbc74d7115f19dd5	d077743b-23cc-4289-8c75-5c5480d723f5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	t	6b02f405e9c1f216f59119d4cf5a53f0ad290e7c24b4190ce42a4a91f4281bd8	2026-08-03 14:51:13.368	2026-07-04 14:51:13.369
869e53d7-793d-4e80-9775-4713f06725bc	3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	6b02f405e9c1f216f59119d4cf5a53f0ad290e7c24b4190ce42a4a91f4281bd8	d077743b-23cc-4289-8c75-5c5480d723f5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 14:51:17.837	2026-07-04 14:51:17.838
48941a55-9224-4fdc-8814-379d23d97edb	4657478c-787b-4192-bf46-7a954fc9bc17	43ade11ed018e887daddc9adc4e91a06a3a69b9a1137b5ec7560848572a16f09	50d0fce4-04b5-49d0-a740-3cc323679bfc	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 15:11:28.712	2026-07-04 15:11:28.713
981b7981-18ba-4d4d-8622-1cd60ed19f0c	4657478c-787b-4192-bf46-7a954fc9bc17	ccba17006a89debe8f07a35ef181e2b114a9055456d3690f3eb6ebdf897f92c5	845165b3-d1a5-43b8-8ae7-75669075bc90	curl/8.7.1	::1	f	\N	2026-08-03 15:12:09.71	2026-07-04 15:12:09.711
91987903-278e-4b5d-a204-60ecbcbc24d3	4657478c-787b-4192-bf46-7a954fc9bc17	ef7fddf72571e7aaf64aefd1bc4d987ad80f5d8823c7f7d5013623d1e00a7123	27194a50-e762-4827-94f6-f7dd68db0038	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36	::1	f	\N	2026-08-03 15:12:27.437	2026-07-04 15:12:27.437
06762892-24f0-4016-aea2-3f35ce7694b4	4657478c-787b-4192-bf46-7a954fc9bc17	1c8d4db81c20eeeccd3c11ae366223af9f17a94d2e86f0c8a3fbbdb5d3041bae	1e0e9719-4a45-439a-a0f3-96d9071cf379	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	::1	f	\N	2026-08-03 16:22:58.72	2026-07-04 16:22:58.722
\.


--
-- Data for Name: rfq_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfq_items (id, "rfqId", "boqItemId", description, unit, quantity, "sortOrder") FROM stdin;
c02e21e7-b5d1-4f8a-a759-1cc4703b8e85	5108731b-705b-425d-9fad-9b0133a5c745	\N	OPC Cement	bag	500	0
0fe1e9db-b6ea-4f36-83d0-78072b88b927	b0f1ab83-ffaf-43ee-b16e-2ce7d5136520	\N	OPC Cement	bag	500	0
b005e930-f88d-47dd-aef1-c4e505fccdd3	b1cf2105-6410-47a5-a6ef-23970139b5ee	\N	OPC Cement	bag	500	0
b57e06bf-5f67-4cff-bcbf-aa8662aaa059	233ffe5d-f739-4121-93d1-b4819f678591	\N	OPC Cement	bag	500	0
c900fed5-dd35-448e-9a03-98ca5d9ea892	d437c0fc-4878-4909-a379-f40897d2b686	\N	OPC Cement	bag	500	0
455eb987-fc1e-46ab-9623-f37842a87c4b	fc9b863f-70c9-4aa8-b835-69a6dfff8630	\N	OPC Cement	bag	500	0
\.


--
-- Data for Name: rfq_quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfq_quotes (id, "rfqItemId", "vendorId", rate, remarks, "updatedAt") FROM stdin;
da0cb5e3-87bd-4005-92b6-54e73a15b9b0	0fe1e9db-b6ea-4f36-83d0-78072b88b927	1f426128-184c-4ea6-9e51-c9423c9b42b1	375	\N	2026-07-04 13:55:46.203
be0f1375-889c-42a6-8f38-ce1003bce1bc	b005e930-f88d-47dd-aef1-c4e505fccdd3	4f875c54-54af-4b9e-85f3-dc174bbaeb0f	375	\N	2026-07-04 13:57:24.001
6845e407-e304-49f1-8c95-8982674e3c3e	b57e06bf-5f67-4cff-bcbf-aa8662aaa059	c5220ab5-06fe-4307-9cea-95c60a3e3cd1	375	\N	2026-07-04 13:58:23.716
078c4452-44ac-42d0-988e-e7ea1e02790c	c900fed5-dd35-448e-9a03-98ca5d9ea892	f9551d89-b587-43a1-867c-040650349875	375	\N	2026-07-04 14:01:03.692
6b3e768a-86f3-4736-a9de-ea0068211c19	455eb987-fc1e-46ab-9623-f37842a87c4b	d0df4401-c24f-4d84-bce6-01686a8fadac	375	\N	2026-07-04 14:02:14.379
\.


--
-- Data for Name: rfq_vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfq_vendors (id, "rfqId", "vendorId", status, "createdAt") FROM stdin;
b88c6fc7-4bdc-4e5b-a3ce-673d43969039	5108731b-705b-425d-9fad-9b0133a5c745	4b85c12e-acf8-4c31-bf3b-d642dac48829	INVITED	2026-07-04 13:54:02.246
6bc820b5-054a-422d-be50-7de3beb482d7	b0f1ab83-ffaf-43ee-b16e-2ce7d5136520	1f426128-184c-4ea6-9e51-c9423c9b42b1	RESPONDED	2026-07-04 13:55:45.922
c7f9b6dc-ff05-4c5b-9fa0-d4a9d1676fcb	b1cf2105-6410-47a5-a6ef-23970139b5ee	4f875c54-54af-4b9e-85f3-dc174bbaeb0f	RESPONDED	2026-07-04 13:57:23.324
b5e8f481-9b9b-4fed-a81f-03741f6ab50a	233ffe5d-f739-4121-93d1-b4819f678591	c5220ab5-06fe-4307-9cea-95c60a3e3cd1	RESPONDED	2026-07-04 13:58:23.472
dd903a7d-967f-46d9-8e22-ff8b99d5a1b1	d437c0fc-4878-4909-a379-f40897d2b686	f9551d89-b587-43a1-867c-040650349875	RESPONDED	2026-07-04 14:01:02.277
53953a13-1d0f-451c-96f0-003d10d0abb1	fc9b863f-70c9-4aa8-b835-69a6dfff8630	d0df4401-c24f-4d84-bce6-01686a8fadac	RESPONDED	2026-07-04 14:02:14.129
\.


--
-- Data for Name: rfqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfqs (id, "tenderId", title, status, "dueDate", "awardedVendorId", "createdById", "createdAt", "updatedAt") FROM stdin;
5108731b-705b-425d-9fad-9b0133a5c745	\N	Cement Supply RFQ 1783173241725	SENT	\N	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:54:02.219	2026-07-04 13:54:02.248
b0f1ab83-ffaf-43ee-b16e-2ce7d5136520	\N	Cement Supply RFQ 1783173345408	SENT	\N	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:55:45.911	2026-07-04 13:55:45.924
b1cf2105-6410-47a5-a6ef-23970139b5ee	\N	Cement Supply RFQ 1783173442434	SENT	\N	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:57:23.265	2026-07-04 13:57:23.327
233ffe5d-f739-4121-93d1-b4819f678591	\N	Cement Supply RFQ 1783173502987	SENT	\N	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:58:23.464	2026-07-04 13:58:23.474
d437c0fc-4878-4909-a379-f40897d2b686	\N	Cement Supply RFQ 1783173661765	AWARDED	\N	f9551d89-b587-43a1-867c-040650349875	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:01:02.26	2026-07-04 14:01:05.62
fc9b863f-70c9-4aa8-b835-69a6dfff8630	\N	Cement Supply RFQ 1783173733633	AWARDED	\N	d0df4401-c24f-4d84-bce6-01686a8fadac	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:02:14.116	2026-07-04 14:02:16.269
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, "roleId", "permissionId", "createdAt") FROM stdin;
6bc5f771-6f02-4dc8-b3f1-7214b582ccb3	ef2b5ffe-0f6b-4092-8f5e-57d385f5385d	773972e0-9181-4e31-ad88-f99192e8f8ea	2026-07-04 05:55:36.894
56bac787-8783-4fa8-a7d4-6bc07a86e375	ab099b77-b67a-4c27-8af4-707eca705e83	a6ef63a6-a1c1-44ac-899f-9748b8ab2f8f	2026-07-04 05:55:36.902
ba23dfba-0641-4918-874f-9c07fd472756	ab099b77-b67a-4c27-8af4-707eca705e83	cecfe86a-a917-482b-94b1-81343a8acc1e	2026-07-04 05:55:36.905
ca278b13-7ee4-4d7b-8fe9-928732873fd1	ab099b77-b67a-4c27-8af4-707eca705e83	9e66766a-e265-4fe3-9908-a61f7fe7d7f1	2026-07-04 05:55:36.908
2dffa89b-4c86-453b-b952-6ec1fdbc08a3	ab099b77-b67a-4c27-8af4-707eca705e83	6ae253f3-0c64-4068-a5e7-2caf5a2b9460	2026-07-04 05:55:36.911
2175421f-2662-430c-830e-00467b76a794	ab099b77-b67a-4c27-8af4-707eca705e83	fd548a31-5f38-470f-85f4-4b1398e56889	2026-07-04 05:55:36.914
029d6e2e-92d1-4f81-a68f-8b1696da8bd5	ab099b77-b67a-4c27-8af4-707eca705e83	2dd273cf-5293-461a-9c5c-9dc057229a88	2026-07-04 05:55:36.918
fd649217-c281-4adf-8469-89f130300b01	ab099b77-b67a-4c27-8af4-707eca705e83	5429cb5e-d339-4115-a5bf-f124f23267a4	2026-07-04 05:55:36.92
f27db95b-54ca-4383-a5e4-599c6da4b099	ab099b77-b67a-4c27-8af4-707eca705e83	8ced55ab-b7fb-4c14-89d1-8b1e48bcf5ef	2026-07-04 05:55:36.923
001bd9cd-b53b-4196-9afe-3640285a7df1	ab099b77-b67a-4c27-8af4-707eca705e83	40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	2026-07-04 05:55:36.926
1ab4f537-e3f9-4642-aed0-de86f901c137	ab099b77-b67a-4c27-8af4-707eca705e83	ea06f0c6-5a54-458b-8f67-f3b59da92bae	2026-07-04 05:55:36.927
8ad7efee-cc7b-4f3a-a948-ec260ab71aca	ab099b77-b67a-4c27-8af4-707eca705e83	1f4b4897-028d-4673-9023-848f4b50c436	2026-07-04 05:55:36.93
be274a4f-2bf5-4147-b110-47bfc1ea196e	ab099b77-b67a-4c27-8af4-707eca705e83	9cc99df5-d416-4b73-8b5f-04a4627ef5fb	2026-07-04 05:55:36.932
afbcbe5f-ee9a-4b05-b464-d8272cca4c5d	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	cecfe86a-a917-482b-94b1-81343a8acc1e	2026-07-04 05:55:36.935
a9960074-4b12-438e-8dfd-39557d4124eb	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	8ced55ab-b7fb-4c14-89d1-8b1e48bcf5ef	2026-07-04 05:55:36.937
d976b19d-fd9a-46b8-abe0-ed2e6e8f4de8	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	2026-07-04 05:55:36.939
d4205cef-54bf-4036-a21d-f30380107b7f	571fa792-8cf4-4c94-aa1b-997bcc2f2490	cecfe86a-a917-482b-94b1-81343a8acc1e	2026-07-04 05:55:36.943
64965971-3ab4-4b96-9e11-2e9c3367138c	571fa792-8cf4-4c94-aa1b-997bcc2f2490	8ced55ab-b7fb-4c14-89d1-8b1e48bcf5ef	2026-07-04 05:55:36.945
2593b2e4-71da-4eb7-a5cb-8dbd2a1a9239	571fa792-8cf4-4c94-aa1b-997bcc2f2490	40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	2026-07-04 05:55:36.948
314b3faa-5193-4b4f-9686-855eb242dfdb	4e47c78d-8085-4d5f-a0ec-13b961236df0	cecfe86a-a917-482b-94b1-81343a8acc1e	2026-07-04 05:55:36.958
bb160a8f-976e-4562-9941-cb78f0f6d87a	4e47c78d-8085-4d5f-a0ec-13b961236df0	8ced55ab-b7fb-4c14-89d1-8b1e48bcf5ef	2026-07-04 05:55:36.96
837a4034-643e-449b-8cf9-393933e92692	4e47c78d-8085-4d5f-a0ec-13b961236df0	40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	2026-07-04 05:55:36.963
890c0be7-20a4-4938-abdc-b4b4a61b934f	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	cecfe86a-a917-482b-94b1-81343a8acc1e	2026-07-04 05:55:36.967
0cf46e77-b428-449d-a74c-4542648c579a	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	8ced55ab-b7fb-4c14-89d1-8b1e48bcf5ef	2026-07-04 05:55:36.97
d786187c-62aa-4c72-990e-c8f43bfd59d3	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	2026-07-04 05:55:36.973
19b42bf3-51f3-4c5a-845b-a4a04d6b3541	d6c64dd5-493e-4cff-86e7-a2fc00403d26	cecfe86a-a917-482b-94b1-81343a8acc1e	2026-07-04 05:55:36.975
f2ada1c6-58be-4f9f-82b9-cbc974803d4b	d6c64dd5-493e-4cff-86e7-a2fc00403d26	8ced55ab-b7fb-4c14-89d1-8b1e48bcf5ef	2026-07-04 05:55:36.977
23c13471-3438-4f3b-8dc9-0b4b96e8c056	d6c64dd5-493e-4cff-86e7-a2fc00403d26	40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	2026-07-04 05:55:36.979
e59c1705-4f2a-4368-a667-25bf45e9a506	8ccbe196-fdb9-4889-87c6-837510cd155d	cecfe86a-a917-482b-94b1-81343a8acc1e	2026-07-04 05:55:36.985
a1b7dc0e-eceb-4fb3-94db-2962a157986e	8ccbe196-fdb9-4889-87c6-837510cd155d	40a7c7d2-a9a9-4e07-bcfc-74f4558304a8	2026-07-04 05:55:36.987
10c10756-2758-4557-9638-b638bb7374ff	ab099b77-b67a-4c27-8af4-707eca705e83	be7674ef-4883-4cdf-953b-e89af8666d7f	2026-07-04 12:06:33.501
555e884d-c1dc-4dd4-ac0a-9408e8e14b8e	ab099b77-b67a-4c27-8af4-707eca705e83	f9440996-a870-4896-950f-c42b56d3db5b	2026-07-04 12:06:33.504
1a205df6-dd6c-4d45-982d-036c057d3ed1	ab099b77-b67a-4c27-8af4-707eca705e83	703cd652-ae51-4a47-937f-8370e5a3acf6	2026-07-04 12:06:33.509
cf021d6a-d3c5-4b96-ad19-67b2ccec8313	ab099b77-b67a-4c27-8af4-707eca705e83	a01523af-34a1-4170-afad-0e06421ff223	2026-07-04 12:06:33.512
1c6d0563-de74-411a-854d-ea1ea31f48d7	ab099b77-b67a-4c27-8af4-707eca705e83	0dfa511a-858c-4545-b58d-c9efb8699fc5	2026-07-04 12:06:33.513
88a885a8-99de-45ac-aa55-8ffc06c85945	ab099b77-b67a-4c27-8af4-707eca705e83	e3698666-90f9-409a-ad10-6be2caf17772	2026-07-04 12:06:33.515
61234d91-29d7-4dc5-96aa-e66474c21f62	ab099b77-b67a-4c27-8af4-707eca705e83	e22ddc29-ea01-4700-af31-c433220b5696	2026-07-04 12:06:33.517
311d9726-f658-4ed5-b1e4-8d83ff489cc7	ab099b77-b67a-4c27-8af4-707eca705e83	1e6eb8ef-f183-41c4-8fbb-85c61cce6050	2026-07-04 12:06:33.519
95611624-4096-4e1f-afd1-78b84c0317c9	ab099b77-b67a-4c27-8af4-707eca705e83	21af72d5-a86d-4581-b4b9-000b9f514e10	2026-07-04 12:06:33.52
3bad2307-ea71-47a7-a051-1dae85671054	ab099b77-b67a-4c27-8af4-707eca705e83	480c806b-1b01-4270-a3d7-565019b7d833	2026-07-04 12:06:33.522
fcc9e102-1b8a-4a64-9d1b-99827ba36944	ab099b77-b67a-4c27-8af4-707eca705e83	6b0fd465-38af-45b5-8a72-099b415df7c7	2026-07-04 12:06:33.523
52668236-75bc-4831-a6b0-c8152f69e486	ab099b77-b67a-4c27-8af4-707eca705e83	564b9586-841f-402d-bdc4-76df5f1a2914	2026-07-04 12:06:33.524
4df18403-91af-480b-aa9f-a966cf0d5854	ab099b77-b67a-4c27-8af4-707eca705e83	0d16929e-3304-4ff8-a47b-a7fcc8f83a66	2026-07-04 12:06:33.526
5e61c514-02d2-4ca3-8a3d-0d5ee85c41c4	ab099b77-b67a-4c27-8af4-707eca705e83	2841b09b-e139-4027-965c-fa3d9d68ea29	2026-07-04 12:06:33.528
468d67b9-39bf-4abf-833f-bbdc40ed91ed	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	f9440996-a870-4896-950f-c42b56d3db5b	2026-07-04 12:06:33.534
33566395-5cb2-43ab-8615-cc55b3f1fea3	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	1e6eb8ef-f183-41c4-8fbb-85c61cce6050	2026-07-04 12:06:33.535
8cc513cb-5703-4dc1-89f7-47a3b3f37a4d	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	564b9586-841f-402d-bdc4-76df5f1a2914	2026-07-04 12:06:33.538
a6b4d01d-dfa5-478f-a132-1b6d9062c5f3	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	be7674ef-4883-4cdf-953b-e89af8666d7f	2026-07-04 12:06:33.54
e6e70e40-0e5b-4472-8322-2c1b3f3435e7	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	703cd652-ae51-4a47-937f-8370e5a3acf6	2026-07-04 12:06:33.542
20ea1464-524b-430c-8def-9e557469d11f	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	a01523af-34a1-4170-afad-0e06421ff223	2026-07-04 12:06:33.543
21abfc8f-51eb-4352-b912-9a6a44758610	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	0dfa511a-858c-4545-b58d-c9efb8699fc5	2026-07-04 12:06:33.544
68bd5319-2286-451f-bf6a-f55d909ef32a	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	e3698666-90f9-409a-ad10-6be2caf17772	2026-07-04 12:06:33.546
2e7dfaa5-70a2-47a6-b25e-6049aa5e3819	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	e22ddc29-ea01-4700-af31-c433220b5696	2026-07-04 12:06:33.548
35f05df4-9164-407d-a478-8319bdd7a085	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	21af72d5-a86d-4581-b4b9-000b9f514e10	2026-07-04 12:06:33.549
de53b747-6b8d-43fd-b4ed-44a23d4fbdea	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	6b0fd465-38af-45b5-8a72-099b415df7c7	2026-07-04 12:06:33.55
eb4b3dd4-7aeb-499b-a2e4-b407f0173dfc	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	0d16929e-3304-4ff8-a47b-a7fcc8f83a66	2026-07-04 12:06:33.552
364ea5d8-908a-4e37-9201-178c0a6f2638	571fa792-8cf4-4c94-aa1b-997bcc2f2490	f9440996-a870-4896-950f-c42b56d3db5b	2026-07-04 12:06:33.562
94495202-ef37-4913-8cce-f5fdd6700949	571fa792-8cf4-4c94-aa1b-997bcc2f2490	1e6eb8ef-f183-41c4-8fbb-85c61cce6050	2026-07-04 12:06:33.563
ed7a6015-11b3-4a3d-b3ae-3b4994e51084	571fa792-8cf4-4c94-aa1b-997bcc2f2490	564b9586-841f-402d-bdc4-76df5f1a2914	2026-07-04 12:06:33.565
0436282a-bb34-44c1-98c8-66a5abf57723	571fa792-8cf4-4c94-aa1b-997bcc2f2490	703cd652-ae51-4a47-937f-8370e5a3acf6	2026-07-04 12:06:33.566
ab47501a-0a66-4f89-82ba-1764c7a1404c	4e47c78d-8085-4d5f-a0ec-13b961236df0	f9440996-a870-4896-950f-c42b56d3db5b	2026-07-04 12:06:33.572
c54c7d97-0032-4e7d-9fb8-479dabb457b6	4e47c78d-8085-4d5f-a0ec-13b961236df0	1e6eb8ef-f183-41c4-8fbb-85c61cce6050	2026-07-04 12:06:33.574
e1f2e4fa-c78a-41eb-a02e-fc96f2fc985c	4e47c78d-8085-4d5f-a0ec-13b961236df0	564b9586-841f-402d-bdc4-76df5f1a2914	2026-07-04 12:06:33.575
58a21bd1-4ca1-4e93-8bd6-590fb486b4b4	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	f9440996-a870-4896-950f-c42b56d3db5b	2026-07-04 12:06:33.582
7115743f-4eee-4f1a-893a-821d12120e99	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	1e6eb8ef-f183-41c4-8fbb-85c61cce6050	2026-07-04 12:06:33.583
f04ec0e5-1291-4a1d-85d8-6d167e01be10	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	564b9586-841f-402d-bdc4-76df5f1a2914	2026-07-04 12:06:33.584
19bdcdc6-85b3-4586-9920-5c78a32ea39b	d6c64dd5-493e-4cff-86e7-a2fc00403d26	f9440996-a870-4896-950f-c42b56d3db5b	2026-07-04 12:06:33.592
387c87a7-f2bc-48c8-8732-a757c6be32c8	d6c64dd5-493e-4cff-86e7-a2fc00403d26	1e6eb8ef-f183-41c4-8fbb-85c61cce6050	2026-07-04 12:06:33.594
dbbb401d-c1e2-4892-a838-4ab177f6c861	d6c64dd5-493e-4cff-86e7-a2fc00403d26	564b9586-841f-402d-bdc4-76df5f1a2914	2026-07-04 12:06:33.595
72472e21-fd45-4460-bc66-899f57ad9529	8ccbe196-fdb9-4889-87c6-837510cd155d	f9440996-a870-4896-950f-c42b56d3db5b	2026-07-04 12:06:33.601
558ea642-e18b-4634-9c9b-3d064232c001	8ccbe196-fdb9-4889-87c6-837510cd155d	1e6eb8ef-f183-41c4-8fbb-85c61cce6050	2026-07-04 12:06:33.603
3ad39897-2609-48ac-87cb-1761370013d2	8ccbe196-fdb9-4889-87c6-837510cd155d	564b9586-841f-402d-bdc4-76df5f1a2914	2026-07-04 12:06:33.604
826109ea-173e-4d4b-84c7-f6f44950ca14	ab099b77-b67a-4c27-8af4-707eca705e83	d3190e77-6a27-49ba-845f-45012f755775	2026-07-04 13:02:31.17
22730232-03e9-4fb7-8250-81b9992ef31b	ab099b77-b67a-4c27-8af4-707eca705e83	35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	2026-07-04 13:02:31.175
c15ca5a3-2daa-4994-beed-303ad47f38e1	ab099b77-b67a-4c27-8af4-707eca705e83	3e005021-6128-4f92-823b-17315336639c	2026-07-04 13:02:31.176
2a6b4280-850f-4223-8828-8e7ac64b7765	ab099b77-b67a-4c27-8af4-707eca705e83	6743dc73-207c-4b8d-a8a1-b95f953c7320	2026-07-04 13:02:31.178
56157bcb-bec7-405d-a589-e3ae06ed4577	ab099b77-b67a-4c27-8af4-707eca705e83	f3fe3a32-fe5f-4c59-8649-f2975cce3f09	2026-07-04 13:02:31.179
8506a57f-65ff-456b-a35c-5dab50ff35cd	ab099b77-b67a-4c27-8af4-707eca705e83	ed7d1c54-773c-40cd-a375-448dba78e74b	2026-07-04 13:02:31.181
058d1f2d-57d6-4c09-b905-aa667b2bd597	ab099b77-b67a-4c27-8af4-707eca705e83	63c6d2f9-aa54-4b4d-837f-5f7e7a6eed62	2026-07-04 13:02:31.183
68548f13-c2c0-4b39-9180-5f4fd09146bb	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	2026-07-04 13:02:31.192
f96d7da2-ca49-4f94-99ef-7d9ff858e0a7	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	ed7d1c54-773c-40cd-a375-448dba78e74b	2026-07-04 13:02:31.194
2b704211-062f-480f-9757-a13d7fd3643f	571fa792-8cf4-4c94-aa1b-997bcc2f2490	35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	2026-07-04 13:02:31.216
7fce37ee-1666-4a51-965f-cc5ca84df0ef	571fa792-8cf4-4c94-aa1b-997bcc2f2490	ed7d1c54-773c-40cd-a375-448dba78e74b	2026-07-04 13:02:31.217
ace352aa-852f-4c26-bde7-c4aba8715293	571fa792-8cf4-4c94-aa1b-997bcc2f2490	d3190e77-6a27-49ba-845f-45012f755775	2026-07-04 13:02:31.22
ac9f1b15-8438-443d-970c-ddcd53ff8c85	571fa792-8cf4-4c94-aa1b-997bcc2f2490	3e005021-6128-4f92-823b-17315336639c	2026-07-04 13:02:31.222
fffaa6d4-60e0-46b5-afc7-86f4595dba01	571fa792-8cf4-4c94-aa1b-997bcc2f2490	6743dc73-207c-4b8d-a8a1-b95f953c7320	2026-07-04 13:02:31.224
8999b3bf-5ace-4617-a499-9b4fd953c896	571fa792-8cf4-4c94-aa1b-997bcc2f2490	f3fe3a32-fe5f-4c59-8649-f2975cce3f09	2026-07-04 13:02:31.225
6030f7b5-c260-4c31-b232-71539a4fcc73	571fa792-8cf4-4c94-aa1b-997bcc2f2490	63c6d2f9-aa54-4b4d-837f-5f7e7a6eed62	2026-07-04 13:02:31.226
5edefb0f-c1f0-4fbd-ae09-15a07d2f2667	4e47c78d-8085-4d5f-a0ec-13b961236df0	35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	2026-07-04 13:02:31.236
428908fd-8f16-445b-8c73-d6e0a4bb3556	4e47c78d-8085-4d5f-a0ec-13b961236df0	ed7d1c54-773c-40cd-a375-448dba78e74b	2026-07-04 13:02:31.239
93b3e84d-e669-405b-9d11-2d68d5e0d0e4	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	2026-07-04 13:02:31.249
a391bed5-6827-400b-b377-fc746883d497	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	ed7d1c54-773c-40cd-a375-448dba78e74b	2026-07-04 13:02:31.25
baae1fdb-476c-485e-a8ef-2a238dd0af32	d6c64dd5-493e-4cff-86e7-a2fc00403d26	35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	2026-07-04 13:02:31.259
ea0fad6b-32c4-4918-af63-a04d4c1f361f	d6c64dd5-493e-4cff-86e7-a2fc00403d26	ed7d1c54-773c-40cd-a375-448dba78e74b	2026-07-04 13:02:31.261
d71b5a50-47b4-4045-aa90-fd403c47c04e	8ccbe196-fdb9-4889-87c6-837510cd155d	35d3c1da-5eb0-463c-9fb2-ab69f2d8c6ea	2026-07-04 13:02:31.27
2a1ecd3d-8ef3-403f-be03-42a1669c3d17	8ccbe196-fdb9-4889-87c6-837510cd155d	ed7d1c54-773c-40cd-a375-448dba78e74b	2026-07-04 13:02:31.272
b325fe89-ae5b-4d7f-9f0f-3fa797c452cd	ab099b77-b67a-4c27-8af4-707eca705e83	93e4fb8f-8de1-4b90-9165-2a7fcd1b6e28	2026-07-04 13:52:00.361
37bb4784-747f-437f-b2f3-0254fdeba4fb	ab099b77-b67a-4c27-8af4-707eca705e83	299c030e-bbfd-4d7e-92f9-8a0ab8474793	2026-07-04 13:52:00.366
d7ba3347-67fb-4b82-9de6-067adeae074f	ab099b77-b67a-4c27-8af4-707eca705e83	ed205752-22c6-41be-a9c4-b33566d2b718	2026-07-04 13:52:00.368
01a5c40c-15b2-4673-836d-46ba89e5801e	ab099b77-b67a-4c27-8af4-707eca705e83	b310d589-5ade-4ea1-8707-7c1168458830	2026-07-04 13:52:00.369
b712e757-e5b5-4bc4-94a5-a2d522d5f9ee	ab099b77-b67a-4c27-8af4-707eca705e83	8b07ea69-d484-48b8-8121-4c944410de4e	2026-07-04 13:52:00.371
43b96dec-1872-4b42-8961-b955c5b0a629	ab099b77-b67a-4c27-8af4-707eca705e83	ab0e1dd4-458b-47b4-9bf1-676c477a895f	2026-07-04 13:52:00.373
e3121a77-a0a5-4760-8613-8b67b5b20baa	ab099b77-b67a-4c27-8af4-707eca705e83	d62bdccb-1b51-405f-bcab-60738c4dcbb7	2026-07-04 13:52:00.374
df28fd58-a061-45e1-a473-62a7443830c4	ab099b77-b67a-4c27-8af4-707eca705e83	a6f2703a-9a4f-4a63-931e-5f3832e97434	2026-07-04 13:52:00.376
1bcb0a6d-828b-4b46-8b94-4f6e5cc6f89d	ab099b77-b67a-4c27-8af4-707eca705e83	8ec2d510-1d10-485e-9f40-b48591df6c46	2026-07-04 13:52:00.377
f7d792d7-1bbc-41f7-8987-c95f72014427	ab099b77-b67a-4c27-8af4-707eca705e83	b4c1d68b-30aa-4a41-b7fb-80aecfc0eeec	2026-07-04 13:52:00.379
4a113dd3-6f2b-40b1-9527-10fbd86a7564	ab099b77-b67a-4c27-8af4-707eca705e83	b035de9c-93ba-42e8-b392-1345807a4e32	2026-07-04 13:52:00.38
47a5936c-4f84-455d-9635-356e66f9344c	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	299c030e-bbfd-4d7e-92f9-8a0ab8474793	2026-07-04 13:52:00.397
a0b7ed51-f011-479b-9154-ab3e441e85bb	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	ab0e1dd4-458b-47b4-9bf1-676c477a895f	2026-07-04 13:52:00.4
75c77f65-9346-45c7-881f-1b6104152d41	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	8ec2d510-1d10-485e-9f40-b48591df6c46	2026-07-04 13:52:00.403
e905d4c5-9970-45b0-93e2-b35019e4146d	571fa792-8cf4-4c94-aa1b-997bcc2f2490	299c030e-bbfd-4d7e-92f9-8a0ab8474793	2026-07-04 13:52:00.435
12db8372-1589-4deb-b3a3-6d152b1e067a	571fa792-8cf4-4c94-aa1b-997bcc2f2490	ab0e1dd4-458b-47b4-9bf1-676c477a895f	2026-07-04 13:52:00.44
3d7c2fc2-5e2f-4c76-b991-9e00c3e6048a	571fa792-8cf4-4c94-aa1b-997bcc2f2490	8ec2d510-1d10-485e-9f40-b48591df6c46	2026-07-04 13:52:00.442
8b218022-3b04-4c7f-b1ce-03f27fb2424a	4e47c78d-8085-4d5f-a0ec-13b961236df0	299c030e-bbfd-4d7e-92f9-8a0ab8474793	2026-07-04 13:52:00.464
c2bab054-6a63-4318-ab3c-23ca3bc3734e	4e47c78d-8085-4d5f-a0ec-13b961236df0	ab0e1dd4-458b-47b4-9bf1-676c477a895f	2026-07-04 13:52:00.465
7fd74708-7920-4283-b3ea-ef2e6a71890c	4e47c78d-8085-4d5f-a0ec-13b961236df0	8ec2d510-1d10-485e-9f40-b48591df6c46	2026-07-04 13:52:00.469
dfb520ea-e6a7-4ccc-ba25-e2b8cc0b3ed9	4e47c78d-8085-4d5f-a0ec-13b961236df0	93e4fb8f-8de1-4b90-9165-2a7fcd1b6e28	2026-07-04 13:52:00.471
97168b95-8178-4a71-9bb2-b5951756ce67	4e47c78d-8085-4d5f-a0ec-13b961236df0	ed205752-22c6-41be-a9c4-b33566d2b718	2026-07-04 13:52:00.473
f1fcf92a-fc57-458f-b767-1c31c962e25e	4e47c78d-8085-4d5f-a0ec-13b961236df0	b310d589-5ade-4ea1-8707-7c1168458830	2026-07-04 13:52:00.474
99c65a76-ee51-4ef2-809c-e572b0098d03	4e47c78d-8085-4d5f-a0ec-13b961236df0	8b07ea69-d484-48b8-8121-4c944410de4e	2026-07-04 13:52:00.476
f064ea8a-2141-49ea-bc93-d501866dcc4b	4e47c78d-8085-4d5f-a0ec-13b961236df0	d62bdccb-1b51-405f-bcab-60738c4dcbb7	2026-07-04 13:52:00.478
f2cdb455-351a-423c-8329-dae95572874e	4e47c78d-8085-4d5f-a0ec-13b961236df0	a6f2703a-9a4f-4a63-931e-5f3832e97434	2026-07-04 13:52:00.479
037429b9-5907-4c17-a7e8-1340becd2127	4e47c78d-8085-4d5f-a0ec-13b961236df0	b4c1d68b-30aa-4a41-b7fb-80aecfc0eeec	2026-07-04 13:52:00.481
9687519c-f4c6-4870-bc66-c568af4a4611	4e47c78d-8085-4d5f-a0ec-13b961236df0	b035de9c-93ba-42e8-b392-1345807a4e32	2026-07-04 13:52:00.482
d0ecafb6-3b8d-4cd8-8b39-9e6e35dbf0a5	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	299c030e-bbfd-4d7e-92f9-8a0ab8474793	2026-07-04 13:52:00.496
fb701f37-ff74-412c-8b97-18ac35a8676d	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	ab0e1dd4-458b-47b4-9bf1-676c477a895f	2026-07-04 13:52:00.498
f3fd138b-d0ca-415f-87cc-5571cfe1ae21	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	8ec2d510-1d10-485e-9f40-b48591df6c46	2026-07-04 13:52:00.499
ca3fd1b5-a83d-486f-a78a-d9b10e046b39	d6c64dd5-493e-4cff-86e7-a2fc00403d26	299c030e-bbfd-4d7e-92f9-8a0ab8474793	2026-07-04 13:52:00.512
04c666ae-2565-4ccf-b448-b7352b99d85f	d6c64dd5-493e-4cff-86e7-a2fc00403d26	ab0e1dd4-458b-47b4-9bf1-676c477a895f	2026-07-04 13:52:00.514
43b168d9-a619-4d73-8c0c-f122c48dbdc2	d6c64dd5-493e-4cff-86e7-a2fc00403d26	8ec2d510-1d10-485e-9f40-b48591df6c46	2026-07-04 13:52:00.516
0ec88121-cf93-47c2-a852-23dfc306e7a8	8ccbe196-fdb9-4889-87c6-837510cd155d	299c030e-bbfd-4d7e-92f9-8a0ab8474793	2026-07-04 13:52:00.526
dd894773-411e-4acd-b1e2-0b295a4e755c	8ccbe196-fdb9-4889-87c6-837510cd155d	ab0e1dd4-458b-47b4-9bf1-676c477a895f	2026-07-04 13:52:00.528
9e3158b1-79d8-495b-9ea4-5c14dab7dd51	8ccbe196-fdb9-4889-87c6-837510cd155d	8ec2d510-1d10-485e-9f40-b48591df6c46	2026-07-04 13:52:00.529
2f55cc7b-ff7c-4ad4-ba4b-36521c3204c0	ab099b77-b67a-4c27-8af4-707eca705e83	f444dde3-0b40-4691-b7bf-c7b659366725	2026-07-04 14:22:05.006
79e51c44-ca42-40ad-bca2-aca165378392	ab099b77-b67a-4c27-8af4-707eca705e83	094ea0d8-d090-477d-a376-8235654612fd	2026-07-04 14:22:05.011
09ac104c-8aa5-443c-beaf-ffa4c6829049	ab099b77-b67a-4c27-8af4-707eca705e83	4261a4be-5ab6-47ca-bc7d-a5386e15ba78	2026-07-04 14:22:05.013
ae8b9781-d61b-4d26-a7da-ad678d99b52a	ab099b77-b67a-4c27-8af4-707eca705e83	d5a92009-ef4e-4075-9609-0e96230885e3	2026-07-04 14:22:05.015
18f9b8f6-79b7-47ab-b7c8-3a8d55b84ca0	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	094ea0d8-d090-477d-a376-8235654612fd	2026-07-04 14:22:05.035
d8d0b5e7-a23c-4d60-8a87-c6655ec8cd39	571fa792-8cf4-4c94-aa1b-997bcc2f2490	094ea0d8-d090-477d-a376-8235654612fd	2026-07-04 14:22:05.07
83e51332-6a97-4202-9175-e8550b84042f	4e47c78d-8085-4d5f-a0ec-13b961236df0	094ea0d8-d090-477d-a376-8235654612fd	2026-07-04 14:22:05.095
6d92e255-0e6f-45e3-8e84-8329d67685ca	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	094ea0d8-d090-477d-a376-8235654612fd	2026-07-04 14:22:05.125
2a241231-fb72-4b1e-a30e-ee73161720eb	d6c64dd5-493e-4cff-86e7-a2fc00403d26	094ea0d8-d090-477d-a376-8235654612fd	2026-07-04 14:22:05.142
c51e9038-2156-474c-8879-5e79c0286208	d6c64dd5-493e-4cff-86e7-a2fc00403d26	f444dde3-0b40-4691-b7bf-c7b659366725	2026-07-04 14:22:05.144
152302de-156f-450f-afd7-e3556c342cd2	d6c64dd5-493e-4cff-86e7-a2fc00403d26	4261a4be-5ab6-47ca-bc7d-a5386e15ba78	2026-07-04 14:22:05.146
3951c16e-47bb-4e57-9838-37cdf7fd51d5	d6c64dd5-493e-4cff-86e7-a2fc00403d26	d5a92009-ef4e-4075-9609-0e96230885e3	2026-07-04 14:22:05.148
2f98d2bd-f7a4-4226-ad3f-72f801c1abad	8ccbe196-fdb9-4889-87c6-837510cd155d	094ea0d8-d090-477d-a376-8235654612fd	2026-07-04 14:22:05.162
c8f5e845-88f2-48fa-b8b7-ae3ad4e1adba	ab099b77-b67a-4c27-8af4-707eca705e83	445f99e4-d8b4-4a39-b619-8e7981d4b5fe	2026-07-04 14:49:32.798
fdd67264-8d3a-4bd8-b36b-607884c5fc1d	ab099b77-b67a-4c27-8af4-707eca705e83	ab6013ab-94d0-499b-9bd0-4de50c1a923e	2026-07-04 14:49:32.8
f883f5ed-b34d-4b42-b7f5-874ef5589ec0	ab099b77-b67a-4c27-8af4-707eca705e83	76f1bc59-238d-42b6-8d71-466eb3dc539b	2026-07-04 14:49:32.801
171bca96-9ed3-4b02-9781-e79480687be3	ab099b77-b67a-4c27-8af4-707eca705e83	2e3cb2ff-ea17-4f4d-91ec-e596dc2ff897	2026-07-04 14:49:32.802
a74834b4-da51-4921-a1cf-73181f5c7dea	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	ab6013ab-94d0-499b-9bd0-4de50c1a923e	2026-07-04 14:49:32.822
794f1f40-3b60-424b-8420-eed4af9c2f97	571fa792-8cf4-4c94-aa1b-997bcc2f2490	ab6013ab-94d0-499b-9bd0-4de50c1a923e	2026-07-04 14:49:32.85
44f82aa0-2f23-48cf-94b4-3cee3dbe5f10	4e47c78d-8085-4d5f-a0ec-13b961236df0	ab6013ab-94d0-499b-9bd0-4de50c1a923e	2026-07-04 14:49:32.874
bbec6a0e-66f2-4b22-83a1-04abe4cee748	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	ab6013ab-94d0-499b-9bd0-4de50c1a923e	2026-07-04 14:49:32.906
86326a2c-b329-4220-a3aa-ec963f5a8b4a	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	445f99e4-d8b4-4a39-b619-8e7981d4b5fe	2026-07-04 14:49:32.911
5426207a-fda6-4aad-af82-e372685612d9	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	76f1bc59-238d-42b6-8d71-466eb3dc539b	2026-07-04 14:49:32.913
684247a7-157f-42ca-ac4d-d086000c6c5d	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	2e3cb2ff-ea17-4f4d-91ec-e596dc2ff897	2026-07-04 14:49:32.914
f8d03549-6660-40ca-90b7-94deb16e4ab7	d6c64dd5-493e-4cff-86e7-a2fc00403d26	ab6013ab-94d0-499b-9bd0-4de50c1a923e	2026-07-04 14:49:32.932
b86470e7-4e14-495e-99d3-e06078def431	8ccbe196-fdb9-4889-87c6-837510cd155d	ab6013ab-94d0-499b-9bd0-4de50c1a923e	2026-07-04 14:49:32.952
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, "isSystem", "createdAt", "updatedAt") FROM stdin;
d6c64dd5-493e-4cff-86e7-a2fc00403d26	PROJECT_MANAGER	Tracks ongoing projects: progress, material, labor, expenses	t	2026-07-04 05:55:36.974	2026-07-04 14:49:32.916
8ccbe196-fdb9-4889-87c6-837510cd155d	VIEWER	Read-only access across the platform	t	2026-07-04 05:55:36.983	2026-07-04 14:49:32.937
ef2b5ffe-0f6b-4092-8f5e-57d385f5385d	SUPER_ADMIN	Complete access to all modules and system configuration	t	2026-07-04 05:55:36.892	2026-07-04 14:49:32.724
ab099b77-b67a-4c27-8af4-707eca705e83	ADMIN	Manages company data and approves workflows; cannot modify system settings	t	2026-07-04 05:55:36.901	2026-07-04 14:49:32.728
de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	TENDER_MANAGER	Creates tenders, uploads documents, assigns estimators, tracks lifecycle	t	2026-07-04 05:55:36.934	2026-07-04 14:49:32.804
571fa792-8cf4-4c94-aa1b-997bcc2f2490	ESTIMATOR	Prepares BOQs, fills rates, generates estimates and comparison sheets	t	2026-07-04 05:55:36.942	2026-07-04 14:49:32.834
4e47c78d-8085-4d5f-a0ec-13b961236df0	PURCHASE_MANAGER	Manages vendors, issues RFQs, creates purchase orders, tracks deliveries	t	2026-07-04 05:55:36.951	2026-07-04 14:49:32.859
319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	ACCOUNTS	Manages bills, payments, invoices, taxes, GST, and financial reports	t	2026-07-04 05:55:36.966	2026-07-04 14:49:32.888
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name, color, "createdAt") FROM stdin;
\.


--
-- Data for Name: tender_assignees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tender_assignees (id, "tenderId", "userId", role, "assignedById", "createdAt") FROM stdin;
93e60718-fa81-4800-9204-76252b7465a1	0ea4ad05-a66a-4856-b0db-533d61b08b20	ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	ESTIMATOR	80831d57-c57c-4d5e-bb18-f22e8a782664	2026-07-04 12:08:43.295
\.


--
-- Data for Name: tender_competitors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tender_competitors (id, "tenderId", "competitorName", "bidAmount", "isWinningBid", remarks, "createdAt") FROM stdin;
\.


--
-- Data for Name: tender_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tender_tags (id, "tenderId", "tagId", "createdAt") FROM stdin;
\.


--
-- Data for Name: tenders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenders (id, "tenderNumber", title, department, "clientId", type, category, location, state, "estimatedCost", "emdAmount", "tenderFee", "documentFee", "submissionDate", "openingDate", "validityPeriodDays", status, "statusChangedAt", priority, description, remarks, "winnerName", "winningBidAmount", "lossReason", "createdById", "createdAt", "updatedAt") FROM stdin;
0ea4ad05-a66a-4856-b0db-533d61b08b20	TND-TEST-001	Road Widening Project	PWD	a3f2e69d-dab0-424c-89b6-8c683fb34750	OPEN	ROAD	Mumbai	Maharashtra	5000000	\N	\N	\N	2026-07-10 00:00:00	\N	\N	UPCOMING	2026-07-04 12:08:43.343	MEDIUM	\N	\N	\N	\N	\N	80831d57-c57c-4d5e-bb18-f22e8a782664	2026-07-04 12:08:17.482	2026-07-04 12:08:43.344
f2e13ccb-39c4-4fdb-b71e-527781f118f8	TND-P5-1783175025146	Phase 5 Highway Project	PWD	a3f2e69d-dab0-424c-89b6-8c683fb34750	OPEN	ROAD	Test City	Test State	500000	\N	\N	\N	2026-07-11 14:23:45.146	\N	\N	WON	2026-07-04 14:23:45.257	MEDIUM	\N	\N	Us	480000	\N	80831d57-c57c-4d5e-bb18-f22e8a782664	2026-07-04 14:23:45.157	2026-07-04 14:23:45.258
a29ba86e-27be-4134-a8cb-43edeec828b4	TND-P5-1783175098665	Phase 5 Highway Project	PWD	a3f2e69d-dab0-424c-89b6-8c683fb34750	OPEN	ROAD	Test City	Test State	500000	\N	\N	\N	2026-07-11 14:24:58.665	\N	\N	WON	2026-07-04 14:24:58.764	MEDIUM	\N	\N	Us	480000	\N	80831d57-c57c-4d5e-bb18-f22e8a782664	2026-07-04 14:24:58.672	2026-07-04 14:24:58.764
1a779b72-7d03-4cef-9d38-fb3d189b2d2f	TND-P5-1783175166479	Phase 5 Highway Project	PWD	a3f2e69d-dab0-424c-89b6-8c683fb34750	OPEN	ROAD	Test City	Test State	500000	\N	\N	\N	2026-07-11 14:26:06.479	\N	\N	WON	2026-07-04 14:26:06.586	MEDIUM	\N	\N	Us	480000	\N	80831d57-c57c-4d5e-bb18-f22e8a782664	2026-07-04 14:26:06.489	2026-07-04 14:26:06.586
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, "passwordHash", "firstName", "lastName", phone, "isActive", "isEmailVerified", "lastLoginAt", "createdById", "roleId", "avatarAttachmentId", "createdAt", "updatedAt") FROM stdin;
7f34ed87-4591-4a5a-939c-a4e1ff96cd0b	admin@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Ava	Admin	\N	t	t	\N	\N	ab099b77-b67a-4c27-8af4-707eca705e83	\N	2026-07-04 05:55:37.251	2026-07-04 05:55:37.251
b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	purchase.manager@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Priya	PurchaseManager	\N	t	t	2026-07-04 14:02:10.013	\N	4e47c78d-8085-4d5f-a0ec-13b961236df0	\N	2026-07-04 05:55:37.258	2026-07-04 14:02:10.013
cf024df1-0ac1-4dc1-8076-2be4a0be22e8	new.hire@example.com	$2b$12$UuDUWpx9ewE6nYnmGPUxluUQGIr4/WBKVMXUQ1HbXE0HLsUKAdm8y	New	Hire		t	f	\N	4657478c-787b-4192-bf46-7a954fc9bc17	571fa792-8cf4-4c94-aa1b-997bcc2f2490	\N	2026-07-04 05:59:17.787	2026-07-04 06:07:39.603
80831d57-c57c-4d5e-bb18-f22e8a782664	tender.manager@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Tanya	TenderManager	\N	t	t	2026-07-04 14:26:06.459	\N	de0ee8c2-cc8c-4eb7-a0a2-2a6e1a152dff	\N	2026-07-04 05:55:37.253	2026-07-04 14:26:06.46
9125a4ce-5438-40ef-a999-2cb595ed4156	project.manager@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Paul	ProjectManager	\N	t	t	2026-07-04 14:26:08.563	\N	d6c64dd5-493e-4cff-86e7-a2fc00403d26	\N	2026-07-04 05:55:37.263	2026-07-04 14:26:08.564
3eb5002b-e82f-4ad6-b1b9-f49e4362c8d9	accounts@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Alex	Accounts	\N	t	t	2026-07-04 14:51:03.145	\N	319f7ba6-0b8d-4d17-95b1-0b881f0f30bc	\N	2026-07-04 05:55:37.26	2026-07-04 14:51:03.145
d07c5c47-66e7-4331-85cd-a0aeb5171e1b	viewer@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Vera	Viewer	\N	t	t	2026-07-04 12:14:53.451	\N	8ccbe196-fdb9-4889-87c6-837510cd155d	\N	2026-07-04 05:55:37.264	2026-07-04 12:14:53.451
ccb330ec-0b2b-4a95-8fcd-a3c7793a50de	estimator@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Ethan	Estimator	\N	t	t	2026-07-04 13:08:03.435	\N	571fa792-8cf4-4c94-aa1b-997bcc2f2490	\N	2026-07-04 05:55:37.255	2026-07-04 13:08:03.436
4657478c-787b-4192-bf46-7a954fc9bc17	superadmin@bmp.local	$2b$12$cQQPtU7UzJR30pXu2MK9X.8pQljBrijLhr2ww3Qt9hc1ohYGoqxdi	Super	Admin	\N	t	t	2026-07-04 15:12:27.444	\N	ef2b5ffe-0f6b-4092-8f5e-57d385f5385d	75fbd89b-5a13-423a-b737-a30f732f41d4	2026-07-04 05:55:37.236	2026-07-04 15:12:27.445
\.


--
-- Data for Name: vendor_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_contacts (id, "vendorId", name, designation, email, phone, "isPrimary", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: vendor_ratings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_ratings (id, "vendorId", "purchaseOrderId", rating, remarks, "ratedById", "createdAt") FROM stdin;
17711e96-b028-41d3-bf85-11f8f16ec576	f9551d89-b587-43a1-867c-040650349875	b6828c4c-f8d6-4f34-bdf3-a1222de46533	5	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:01:10.924
f8870e74-e2e6-48ad-a672-77abb44dac19	d0df4401-c24f-4d84-bce6-01686a8fadac	17974ee2-ff59-40f1-90fa-022a968c79d4	5	\N	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:02:20.337
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, name, category, "gstNumber", "panNumber", address, city, state, "bankAccountName", "bankAccountNumber", "bankIfscCode", notes, "isActive", "createdById", "createdAt", "updatedAt") FROM stdin;
4b85c12e-acf8-4c31-bf3b-d642dac48829	Ace Steel Suppliers 1783173236331	MATERIAL_SUPPLIER										t	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:53:56.398	2026-07-04 13:53:56.398
1f426128-184c-4ea6-9e51-c9423c9b42b1	Ace Steel Suppliers 1783173342902	MATERIAL_SUPPLIER										t	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:55:42.96	2026-07-04 13:55:42.96
4f875c54-54af-4b9e-85f3-dc174bbaeb0f	Ace Steel Suppliers 1783173439088	MATERIAL_SUPPLIER										t	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:57:19.162	2026-07-04 13:57:19.162
c5220ab5-06fe-4307-9cea-95c60a3e3cd1	Ace Steel Suppliers 1783173500591	MATERIAL_SUPPLIER										t	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 13:58:20.657	2026-07-04 13:58:20.657
f9551d89-b587-43a1-867c-040650349875	Ace Steel Suppliers 1783173656917	MATERIAL_SUPPLIER										t	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:00:56.997	2026-07-04 14:00:56.997
d0df4401-c24f-4d84-bce6-01686a8fadac	Ace Steel Suppliers 1783173731357	MATERIAL_SUPPLIER										t	b99ee663-9a6f-46df-9051-0d3b7b3fc9d5	2026-07-04 14:02:11.434	2026-07-04 14:02:11.434
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: boq_item_rate_breakdowns boq_item_rate_breakdowns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boq_item_rate_breakdowns
    ADD CONSTRAINT boq_item_rate_breakdowns_pkey PRIMARY KEY (id);


--
-- Name: boq_items boq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boq_items
    ADD CONSTRAINT boq_items_pkey PRIMARY KEY (id);


--
-- Name: boqs boqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boqs
    ADD CONSTRAINT boqs_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_items goods_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_pkey PRIMARY KEY (id);


--
-- Name: goods_receipts goods_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_pkey PRIMARY KEY (id);


--
-- Name: historical_rates historical_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_rates
    ADD CONSTRAINT historical_rates_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_contacts organization_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_contacts
    ADD CONSTRAINT organization_contacts_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: project_bills project_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_bills
    ADD CONSTRAINT project_bills_pkey PRIMARY KEY (id);


--
-- Name: project_labor_entries project_labor_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_labor_entries
    ADD CONSTRAINT project_labor_entries_pkey PRIMARY KEY (id);


--
-- Name: project_material_usages project_material_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_usages
    ADD CONSTRAINT project_material_usages_pkey PRIMARY KEY (id);


--
-- Name: project_milestones project_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT project_milestones_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: rfq_items rfq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_pkey PRIMARY KEY (id);


--
-- Name: rfq_quotes rfq_quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_quotes
    ADD CONSTRAINT rfq_quotes_pkey PRIMARY KEY (id);


--
-- Name: rfq_vendors rfq_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_vendors
    ADD CONSTRAINT rfq_vendors_pkey PRIMARY KEY (id);


--
-- Name: rfqs rfqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tender_assignees tender_assignees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_assignees
    ADD CONSTRAINT tender_assignees_pkey PRIMARY KEY (id);


--
-- Name: tender_competitors tender_competitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_competitors
    ADD CONSTRAINT tender_competitors_pkey PRIMARY KEY (id);


--
-- Name: tender_tags tender_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_tags
    ADD CONSTRAINT tender_tags_pkey PRIMARY KEY (id);


--
-- Name: tenders tenders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenders
    ADD CONSTRAINT tenders_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendor_contacts vendor_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT vendor_contacts_pkey PRIMARY KEY (id);


--
-- Name: vendor_ratings vendor_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_ratings
    ADD CONSTRAINT vendor_ratings_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: attachments_documentGroupId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "attachments_documentGroupId_idx" ON public.attachments USING btree ("documentGroupId");


--
-- Name: attachments_entityType_entityId_documentType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "attachments_entityType_entityId_documentType_idx" ON public.attachments USING btree ("entityType", "entityId", "documentType");


--
-- Name: attachments_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "attachments_entityType_entityId_idx" ON public.attachments USING btree ("entityType", "entityId");


--
-- Name: attachments_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachments_hash_idx ON public.attachments USING btree (hash);


--
-- Name: attachments_parentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "attachments_parentId_idx" ON public.attachments USING btree ("parentId");


--
-- Name: audit_logs_actorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_actorId_idx" ON public.audit_logs USING btree ("actorId");


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: boq_item_rate_breakdowns_boqItemId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "boq_item_rate_breakdowns_boqItemId_key" ON public.boq_item_rate_breakdowns USING btree ("boqItemId");


--
-- Name: boq_items_boqId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "boq_items_boqId_idx" ON public.boq_items USING btree ("boqId");


--
-- Name: boq_items_parentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "boq_items_parentId_idx" ON public.boq_items USING btree ("parentId");


--
-- Name: boqs_groupId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "boqs_groupId_idx" ON public.boqs USING btree ("groupId");


--
-- Name: boqs_tenderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "boqs_tenderId_idx" ON public.boqs USING btree ("tenderId");


--
-- Name: email_verification_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "email_verification_tokens_tokenHash_key" ON public.email_verification_tokens USING btree ("tokenHash");


--
-- Name: email_verification_tokens_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_verification_tokens_userId_idx" ON public.email_verification_tokens USING btree ("userId");


--
-- Name: goods_receipt_items_goodsReceiptId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "goods_receipt_items_goodsReceiptId_idx" ON public.goods_receipt_items USING btree ("goodsReceiptId");


--
-- Name: goods_receipt_items_purchaseOrderItemId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "goods_receipt_items_purchaseOrderItemId_idx" ON public.goods_receipt_items USING btree ("purchaseOrderItemId");


--
-- Name: goods_receipts_purchaseOrderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "goods_receipts_purchaseOrderId_idx" ON public.goods_receipts USING btree ("purchaseOrderId");


--
-- Name: historical_rates_category_itemName_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "historical_rates_category_itemName_idx" ON public.historical_rates USING btree (category, "itemName");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_sourceBillId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "invoices_sourceBillId_key" ON public.invoices USING btree ("sourceBillId");


--
-- Name: notifications_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_entityType_entityId_idx" ON public.notifications USING btree ("entityType", "entityId");


--
-- Name: notifications_userId_isRead_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_userId_isRead_createdAt_idx" ON public.notifications USING btree ("userId", "isRead", "createdAt");


--
-- Name: organization_contacts_organizationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "organization_contacts_organizationId_idx" ON public.organization_contacts USING btree ("organizationId");


--
-- Name: organizations_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX organizations_name_idx ON public.organizations USING btree (name);


--
-- Name: password_reset_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "password_reset_tokens_tokenHash_key" ON public.password_reset_tokens USING btree ("tokenHash");


--
-- Name: password_reset_tokens_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "password_reset_tokens_userId_idx" ON public.password_reset_tokens USING btree ("userId");


--
-- Name: payments_bankAccountId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "payments_bankAccountId_idx" ON public.payments USING btree ("bankAccountId");


--
-- Name: payments_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "payments_entityType_entityId_idx" ON public.payments USING btree ("entityType", "entityId");


--
-- Name: permissions_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_key_key ON public.permissions USING btree (key);


--
-- Name: permissions_resource_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permissions_resource_idx ON public.permissions USING btree (resource);


--
-- Name: project_bills_projectId_billNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "project_bills_projectId_billNumber_key" ON public.project_bills USING btree ("projectId", "billNumber");


--
-- Name: project_bills_projectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_bills_projectId_idx" ON public.project_bills USING btree ("projectId");


--
-- Name: project_labor_entries_projectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_labor_entries_projectId_idx" ON public.project_labor_entries USING btree ("projectId");


--
-- Name: project_material_usages_projectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_material_usages_projectId_idx" ON public.project_material_usages USING btree ("projectId");


--
-- Name: project_milestones_projectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_milestones_projectId_idx" ON public.project_milestones USING btree ("projectId");


--
-- Name: projects_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_status_idx ON public.projects USING btree (status);


--
-- Name: projects_tenderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "projects_tenderId_key" ON public.projects USING btree ("tenderId");


--
-- Name: purchase_order_items_purchaseOrderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "purchase_order_items_purchaseOrderId_idx" ON public.purchase_order_items USING btree ("purchaseOrderId");


--
-- Name: purchase_orders_poNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "purchase_orders_poNumber_key" ON public.purchase_orders USING btree ("poNumber");


--
-- Name: purchase_orders_tenderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "purchase_orders_tenderId_idx" ON public.purchase_orders USING btree ("tenderId");


--
-- Name: purchase_orders_vendorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "purchase_orders_vendorId_idx" ON public.purchase_orders USING btree ("vendorId");


--
-- Name: refresh_tokens_family_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_family_idx ON public.refresh_tokens USING btree (family);


--
-- Name: refresh_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "refresh_tokens_tokenHash_key" ON public.refresh_tokens USING btree ("tokenHash");


--
-- Name: refresh_tokens_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "refresh_tokens_userId_idx" ON public.refresh_tokens USING btree ("userId");


--
-- Name: rfq_items_rfqId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "rfq_items_rfqId_idx" ON public.rfq_items USING btree ("rfqId");


--
-- Name: rfq_quotes_rfqItemId_vendorId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "rfq_quotes_rfqItemId_vendorId_key" ON public.rfq_quotes USING btree ("rfqItemId", "vendorId");


--
-- Name: rfq_quotes_vendorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "rfq_quotes_vendorId_idx" ON public.rfq_quotes USING btree ("vendorId");


--
-- Name: rfq_vendors_rfqId_vendorId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "rfq_vendors_rfqId_vendorId_key" ON public.rfq_vendors USING btree ("rfqId", "vendorId");


--
-- Name: rfq_vendors_vendorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "rfq_vendors_vendorId_idx" ON public.rfq_vendors USING btree ("vendorId");


--
-- Name: rfqs_tenderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "rfqs_tenderId_idx" ON public.rfqs USING btree ("tenderId");


--
-- Name: role_permissions_permissionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "role_permissions_permissionId_idx" ON public.role_permissions USING btree ("permissionId");


--
-- Name: role_permissions_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "role_permissions_roleId_permissionId_key" ON public.role_permissions USING btree ("roleId", "permissionId");


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: tags_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tags_name_key ON public.tags USING btree (name);


--
-- Name: tender_assignees_tenderId_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tender_assignees_tenderId_userId_key" ON public.tender_assignees USING btree ("tenderId", "userId");


--
-- Name: tender_assignees_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tender_assignees_userId_idx" ON public.tender_assignees USING btree ("userId");


--
-- Name: tender_competitors_tenderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tender_competitors_tenderId_idx" ON public.tender_competitors USING btree ("tenderId");


--
-- Name: tender_tags_tagId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tender_tags_tagId_idx" ON public.tender_tags USING btree ("tagId");


--
-- Name: tender_tags_tenderId_tagId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tender_tags_tenderId_tagId_key" ON public.tender_tags USING btree ("tenderId", "tagId");


--
-- Name: tenders_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tenders_clientId_idx" ON public.tenders USING btree ("clientId");


--
-- Name: tenders_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenders_status_idx ON public.tenders USING btree (status);


--
-- Name: tenders_submissionDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tenders_submissionDate_idx" ON public.tenders USING btree ("submissionDate");


--
-- Name: tenders_tenderNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tenders_tenderNumber_key" ON public.tenders USING btree ("tenderNumber");


--
-- Name: users_avatarAttachmentId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "users_avatarAttachmentId_key" ON public.users USING btree ("avatarAttachmentId");


--
-- Name: users_createdById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_createdById_idx" ON public.users USING btree ("createdById");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_roleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_roleId_idx" ON public.users USING btree ("roleId");


--
-- Name: vendor_contacts_vendorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "vendor_contacts_vendorId_idx" ON public.vendor_contacts USING btree ("vendorId");


--
-- Name: vendor_ratings_purchaseOrderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "vendor_ratings_purchaseOrderId_key" ON public.vendor_ratings USING btree ("purchaseOrderId");


--
-- Name: vendor_ratings_vendorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "vendor_ratings_vendorId_idx" ON public.vendor_ratings USING btree ("vendorId");


--
-- Name: vendors_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vendors_name_idx ON public.vendors USING btree (name);


--
-- Name: attachments attachments_documentGroupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT "attachments_documentGroupId_fkey" FOREIGN KEY ("documentGroupId") REFERENCES public.attachments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: attachments attachments_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT "attachments_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.attachments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attachments attachments_uploadedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT "attachments_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_actorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bank_accounts bank_accounts_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT "bank_accounts_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: boq_item_rate_breakdowns boq_item_rate_breakdowns_boqItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boq_item_rate_breakdowns
    ADD CONSTRAINT "boq_item_rate_breakdowns_boqItemId_fkey" FOREIGN KEY ("boqItemId") REFERENCES public.boq_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: boq_items boq_items_boqId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boq_items
    ADD CONSTRAINT "boq_items_boqId_fkey" FOREIGN KEY ("boqId") REFERENCES public.boqs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: boq_items boq_items_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boq_items
    ADD CONSTRAINT "boq_items_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.boq_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: boqs boqs_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boqs
    ADD CONSTRAINT "boqs_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: boqs boqs_tenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boqs
    ADD CONSTRAINT "boqs_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES public.tenders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT "email_verification_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expenses expenses_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: expenses expenses_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: goods_receipt_items goods_receipt_items_goodsReceiptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT "goods_receipt_items_goodsReceiptId_fkey" FOREIGN KEY ("goodsReceiptId") REFERENCES public.goods_receipts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_receipt_items goods_receipt_items_purchaseOrderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT "goods_receipt_items_purchaseOrderItemId_fkey" FOREIGN KEY ("purchaseOrderItemId") REFERENCES public.purchase_order_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_receipts goods_receipts_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT "goods_receipts_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_receipts goods_receipts_receivedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT "goods_receipts_receivedById_fkey" FOREIGN KEY ("receivedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: historical_rates historical_rates_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_rates
    ADD CONSTRAINT "historical_rates_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_sourceBillId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_sourceBillId_fkey" FOREIGN KEY ("sourceBillId") REFERENCES public.project_bills(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: organization_contacts organization_contacts_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_contacts
    ADD CONSTRAINT "organization_contacts_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: organizations organizations_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT "organizations_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: password_reset_tokens password_reset_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT "password_reset_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_bankAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES public.bank_accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: project_bills project_bills_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_bills
    ADD CONSTRAINT "project_bills_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: project_bills project_bills_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_bills
    ADD CONSTRAINT "project_bills_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_labor_entries project_labor_entries_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_labor_entries
    ADD CONSTRAINT "project_labor_entries_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_labor_entries project_labor_entries_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_labor_entries
    ADD CONSTRAINT "project_labor_entries_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: project_material_usages project_material_usages_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_usages
    ADD CONSTRAINT "project_material_usages_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_material_usages project_material_usages_recordedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_material_usages
    ADD CONSTRAINT "project_material_usages_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: project_milestones project_milestones_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT "project_milestones_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: projects projects_tenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES public.tenders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_sourceRfqId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_sourceRfqId_fkey" FOREIGN KEY ("sourceRfqId") REFERENCES public.rfqs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_tenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES public.tenders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_items rfq_items_rfqId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT "rfq_items_rfqId_fkey" FOREIGN KEY ("rfqId") REFERENCES public.rfqs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_quotes rfq_quotes_rfqItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_quotes
    ADD CONSTRAINT "rfq_quotes_rfqItemId_fkey" FOREIGN KEY ("rfqItemId") REFERENCES public.rfq_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_quotes rfq_quotes_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_quotes
    ADD CONSTRAINT "rfq_quotes_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_vendors rfq_vendors_rfqId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_vendors
    ADD CONSTRAINT "rfq_vendors_rfqId_fkey" FOREIGN KEY ("rfqId") REFERENCES public.rfqs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_vendors rfq_vendors_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_vendors
    ADD CONSTRAINT "rfq_vendors_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfqs rfqs_awardedVendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT "rfqs_awardedVendorId_fkey" FOREIGN KEY ("awardedVendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rfqs rfqs_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT "rfqs_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rfqs rfqs_tenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT "rfqs_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES public.tenders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_permissions role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tender_assignees tender_assignees_assignedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_assignees
    ADD CONSTRAINT "tender_assignees_assignedById_fkey" FOREIGN KEY ("assignedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tender_assignees tender_assignees_tenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_assignees
    ADD CONSTRAINT "tender_assignees_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES public.tenders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tender_assignees tender_assignees_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_assignees
    ADD CONSTRAINT "tender_assignees_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tender_competitors tender_competitors_tenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_competitors
    ADD CONSTRAINT "tender_competitors_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES public.tenders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tender_tags tender_tags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_tags
    ADD CONSTRAINT "tender_tags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tender_tags tender_tags_tenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_tags
    ADD CONSTRAINT "tender_tags_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES public.tenders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenders tenders_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenders
    ADD CONSTRAINT "tenders_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tenders tenders_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenders
    ADD CONSTRAINT "tenders_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users users_avatarAttachmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_avatarAttachmentId_fkey" FOREIGN KEY ("avatarAttachmentId") REFERENCES public.attachments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendor_contacts vendor_contacts_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT "vendor_contacts_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendor_ratings vendor_ratings_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_ratings
    ADD CONSTRAINT "vendor_ratings_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendor_ratings vendor_ratings_ratedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_ratings
    ADD CONSTRAINT "vendor_ratings_ratedById_fkey" FOREIGN KEY ("ratedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendor_ratings vendor_ratings_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_ratings
    ADD CONSTRAINT "vendor_ratings_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendors vendors_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT "vendors_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict TuJxUmhKeLPlDmhXTutP6IUKXDd04zWxhT2wAraBShi33XmU4Vueaa08P6R6yPq

